-- 005_parameter_change_log.sql
-- Section 4 -- TABLE: parameter_change_log
-- Immutable: rows are only ever inserted (BR-03), never updated/deleted.

CREATE TABLE parameter_change_log (
  id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  habitation_id  UUID NOT NULL REFERENCES habitations(id) ON DELETE CASCADE,
  category       VARCHAR(40) NOT NULL,
  field_name     VARCHAR(60) NOT NULL,
  old_value      TEXT,
  new_value      TEXT NOT NULL,
  changed_by     UUID NOT NULL REFERENCES users(id),
  changed_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_change_log_habitation_category ON parameter_change_log (habitation_id, category, changed_at DESC);

-- Enforce immutability at the database level: no UPDATE or DELETE.
REVOKE UPDATE, DELETE ON parameter_change_log FROM PUBLIC;
