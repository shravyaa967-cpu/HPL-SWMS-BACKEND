-- 004_parameter_categories.sql
-- Section 4 (Data Model) -- the seven parameter-category tables.
-- Every table shares one identical structural pattern (see design doc
-- Section 4 note): id (PK), habitation_id (FK, unique), category fields,
-- version (optimistic locking), updated_at, updated_by.
--
-- Section 13.2 (Innovation -- Data Confidence & Lineage Layer) adds four
-- additive columns to every one of these tables: source, capture_method,
-- confidence_score, last_verified_at. All four are optional and default
-- safely, so no existing required field or API contract changes.

CREATE TYPE capture_method AS ENUM ('measured', 'estimated', 'imported', 'default');
CREATE TYPE activity_intensity AS ENUM ('low', 'medium', 'high');
CREATE TYPE accessibility_level AS ENUM ('low', 'medium', 'high');
CREATE TYPE cost_constraint AS ENUM ('low', 'moderate', 'high', 'severe');
CREATE TYPE flood_risk AS ENUM ('low', 'medium', 'high');

-- Shared lineage columns are repeated on every table below (Postgres has
-- no table-mixin syntax); src/modules/parameters/parameter.categories.ts
-- is the single source of truth that keeps them in sync at the app layer.

-- 1. Demography (exemplar table)
CREATE TABLE demography_parameters (
  id                            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  habitation_id                 UUID NOT NULL UNIQUE REFERENCES habitations(id) ON DELETE CASCADE,
  population                    INTEGER NOT NULL,
  population_density_per_sq_km  INTEGER NOT NULL,
  growth_rate_pct               DECIMAL(4,2) NOT NULL DEFAULT 0,
  floating_pop_pct              DECIMAL(5,2) DEFAULT 0,
  household_size                DECIMAL(3,1),
  literacy_pct                  DECIMAL(5,2),
  -- lineage (Section 13.2)
  source                        VARCHAR(120),
  capture_method                capture_method NOT NULL DEFAULT 'default',
  confidence_score              DECIMAL(3,2) NOT NULL DEFAULT 0.50 CHECK (confidence_score BETWEEN 0 AND 1),
  last_verified_at              TIMESTAMPTZ,
  -- concurrency + audit
  version                       INTEGER NOT NULL DEFAULT 1,
  updated_at                    TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_by                    UUID NOT NULL REFERENCES users(id)
);

-- 2. Community Infrastructure
CREATE TABLE infrastructure_parameters (
  id                              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  habitation_id                   UUID NOT NULL UNIQUE REFERENCES habitations(id) ON DELETE CASCADE,
  road_coverage_pct               DECIMAL(5,2) NOT NULL,
  roads_alleys_count               INTEGER NOT NULL DEFAULT 0,
  residential_zone_pct            DECIMAL(5,2) NOT NULL DEFAULT 0,
  industrial_zone_pct             DECIMAL(5,2) NOT NULL DEFAULT 0,
  schools_count                   INTEGER NOT NULL DEFAULT 0,
  clinics_count                   INTEGER NOT NULL DEFAULT 0,
  collection_vehicles             INTEGER NOT NULL DEFAULT 0,
  collection_point_density_pct    DECIMAL(5,2) DEFAULT 0,
  existing_landfill_capacity_tonnes DECIMAL(12,2) DEFAULT 0,
  source                          VARCHAR(120),
  capture_method                  capture_method NOT NULL DEFAULT 'default',
  confidence_score                DECIMAL(3,2) NOT NULL DEFAULT 0.50 CHECK (confidence_score BETWEEN 0 AND 1),
  last_verified_at                TIMESTAMPTZ,
  version                         INTEGER NOT NULL DEFAULT 1,
  updated_at                      TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_by                      UUID NOT NULL REFERENCES users(id)
);

-- 3. Industrial Activities
CREATE TABLE industrial_parameters (
  id                            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  habitation_id                 UUID NOT NULL UNIQUE REFERENCES habitations(id) ON DELETE CASCADE,
  has_organized_industry        BOOLEAN NOT NULL DEFAULT false,
  has_unorganized_industry      BOOLEAN NOT NULL DEFAULT false,
  industrial_activity_intensity activity_intensity NOT NULL DEFAULT 'low',
  industrial_waste_tonnes_per_day DECIMAL(10,2) DEFAULT 0,
  hazardous_share_pct           DECIMAL(5,2) DEFAULT 0,
  source                        VARCHAR(120),
  capture_method                capture_method NOT NULL DEFAULT 'default',
  confidence_score              DECIMAL(3,2) NOT NULL DEFAULT 0.50 CHECK (confidence_score BETWEEN 0 AND 1),
  last_verified_at              TIMESTAMPTZ,
  version                       INTEGER NOT NULL DEFAULT 1,
  updated_at                    TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_by                    UUID NOT NULL REFERENCES users(id)
);

-- 4. Natural Resources
CREATE TABLE natural_resource_parameters (
  id                   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  habitation_id        UUID NOT NULL UNIQUE REFERENCES habitations(id) ON DELETE CASCADE,
  annual_rainfall_mm   DECIMAL(7,2) NOT NULL,
  water_bodies_count   INTEGER NOT NULL DEFAULT 0,
  forest_cover_pct     DECIMAL(5,2) DEFAULT 0,
  sensitive_area_nearby BOOLEAN NOT NULL DEFAULT false,
  source               VARCHAR(120),
  capture_method       capture_method NOT NULL DEFAULT 'default',
  confidence_score     DECIMAL(3,2) NOT NULL DEFAULT 0.50 CHECK (confidence_score BETWEEN 0 AND 1),
  last_verified_at     TIMESTAMPTZ,
  version              INTEGER NOT NULL DEFAULT 1,
  updated_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_by           UUID NOT NULL REFERENCES users(id)
);

-- 5. Terrain
CREATE TABLE terrain_parameters (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  habitation_id   UUID NOT NULL UNIQUE REFERENCES habitations(id) ON DELETE CASCADE,
  slope           VARCHAR(40) NOT NULL,
  soil_type       VARCHAR(60) NOT NULL,
  wind_condition  VARCHAR(60),
  accessibility   accessibility_level NOT NULL DEFAULT 'medium',
  flood_prone     BOOLEAN NOT NULL DEFAULT false,
  -- Section 13.6 (Innovation, future/schema-only): derived disaster-readiness hook.
  -- Not populated by any Drop-1 endpoint; reserved for the Drop 2 calamity module.
  flood_risk_zone flood_risk,
  source          VARCHAR(120),
  capture_method  capture_method NOT NULL DEFAULT 'default',
  confidence_score DECIMAL(3,2) NOT NULL DEFAULT 0.50 CHECK (confidence_score BETWEEN 0 AND 1),
  last_verified_at TIMESTAMPTZ,
  version         INTEGER NOT NULL DEFAULT 1,
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_by      UUID NOT NULL REFERENCES users(id)
);

-- 6. Economic Conditions
CREATE TABLE economic_parameters (
  id                        UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  habitation_id             UUID NOT NULL UNIQUE REFERENCES habitations(id) ON DELETE CASCADE,
  per_capita_income_annual  DECIMAL(12,2) NOT NULL,
  annual_budget_inr         DECIMAL(14,2) NOT NULL,
  willingness_to_pay_pct    DECIMAL(5,2) DEFAULT 0,
  cost_constraint_level     cost_constraint NOT NULL DEFAULT 'moderate',
  source                    VARCHAR(120),
  capture_method            capture_method NOT NULL DEFAULT 'default',
  confidence_score          DECIMAL(3,2) NOT NULL DEFAULT 0.50 CHECK (confidence_score BETWEEN 0 AND 1),
  last_verified_at          TIMESTAMPTZ,
  version                   INTEGER NOT NULL DEFAULT 1,
  updated_at                TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_by                UUID NOT NULL REFERENCES users(id)
);

-- 7. Cultural Significance
CREATE TABLE cultural_parameters (
  id                       UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  habitation_id            UUID NOT NULL UNIQUE REFERENCES habitations(id) ON DELETE CASCADE,
  diet_type                VARCHAR(60),
  segregation_adherence_pct DECIMAL(5,2) DEFAULT 0,
  festival_spike_pct       DECIMAL(5,2) DEFAULT 0,
  local_practice_notes     TEXT,
  source                   VARCHAR(120),
  capture_method           capture_method NOT NULL DEFAULT 'default',
  confidence_score         DECIMAL(3,2) NOT NULL DEFAULT 0.50 CHECK (confidence_score BETWEEN 0 AND 1),
  last_verified_at         TIMESTAMPTZ,
  version                  INTEGER NOT NULL DEFAULT 1,
  updated_at               TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_by               UUID NOT NULL REFERENCES users(id)
);

CREATE INDEX idx_demography_habitation ON demography_parameters (habitation_id);
CREATE INDEX idx_infrastructure_habitation ON infrastructure_parameters (habitation_id);
CREATE INDEX idx_industrial_habitation ON industrial_parameters (habitation_id);
CREATE INDEX idx_natural_resource_habitation ON natural_resource_parameters (habitation_id);
CREATE INDEX idx_terrain_habitation ON terrain_parameters (habitation_id);
CREATE INDEX idx_economic_habitation ON economic_parameters (habitation_id);
CREATE INDEX idx_cultural_habitation ON cultural_parameters (habitation_id);
