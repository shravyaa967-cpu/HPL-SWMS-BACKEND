-- 006_map_layers.sql
-- Section 4 -- TABLE: map_layers
-- One row = one geometry feature. A "layer" (e.g. "roads") is the set of
-- rows sharing the same (habitation_id, layer_type). GIST index for
-- spatial queries + overlay; btree for the common filter pattern.

CREATE TYPE layer_type AS ENUM ('road', 'water_body', 'terrain', 'settlement', 'boundary');
CREATE TYPE layer_status AS ENUM ('processing', 'ready', 'failed');

CREATE TABLE map_layers (
  id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  habitation_id    UUID NOT NULL REFERENCES habitations(id) ON DELETE RESTRICT,
  layer_type       layer_type NOT NULL,
  geometry         GEOMETRY NOT NULL,
  source_file_url  VARCHAR(500) NOT NULL,
  status           layer_status NOT NULL DEFAULT 'processing',
  failure_reason   TEXT,
  -- Section 13.2 (Innovation -- lineage, extended to GIS layers)
  source           VARCHAR(120),
  capture_method   capture_method NOT NULL DEFAULT 'imported',
  confidence_score DECIMAL(3,2) NOT NULL DEFAULT 0.50 CHECK (confidence_score BETWEEN 0 AND 1),
  last_verified_at TIMESTAMPTZ,
  is_deleted       BOOLEAN NOT NULL DEFAULT false,
  deleted_at       TIMESTAMPTZ,
  uploaded_by      UUID NOT NULL REFERENCES users(id),
  uploaded_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_map_layers_geometry ON map_layers USING GIST (geometry);
CREATE INDEX idx_map_layers_lookup ON map_layers (habitation_id, layer_type, status);
