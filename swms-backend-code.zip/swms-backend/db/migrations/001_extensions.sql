-- 001_extensions.sql
-- Enables UUID generation and PostGIS spatial types/functions.

CREATE EXTENSION IF NOT EXISTS "pgcrypto";   -- gen_random_uuid()
CREATE EXTENSION IF NOT EXISTS "postgis";
