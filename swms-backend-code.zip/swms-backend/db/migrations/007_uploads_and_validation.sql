-- 007_uploads_and_validation.sql
-- Section 4 -- TABLE: upload_batches, TABLE: validation_issues

CREATE TYPE upload_target AS ENUM ('parameter', 'map_layer');
CREATE TYPE batch_status AS ENUM ('pending', 'validating', 'validated', 'partially_validated', 'failed');
CREATE TYPE issue_severity AS ENUM ('error', 'warning');

CREATE TABLE upload_batches (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  habitation_id   UUID NOT NULL REFERENCES habitations(id) ON DELETE CASCADE,
  target_type     upload_target NOT NULL,
  category        VARCHAR(40) NOT NULL, -- parameter category name, or map layer_type
  original_filename VARCHAR(255) NOT NULL,
  file_checksum   CHAR(64) NOT NULL, -- SHA-256 hex digest (BR-07 duplicate detection)
  storage_key     VARCHAR(500) NOT NULL,
  status          batch_status NOT NULL DEFAULT 'pending',
  row_count       INTEGER,
  error_count     INTEGER NOT NULL DEFAULT 0,
  warning_count   INTEGER NOT NULL DEFAULT 0,
  uploaded_by     UUID NOT NULL REFERENCES users(id),
  uploaded_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  processed_at    TIMESTAMPTZ
);

-- BR-07: identical (habitation, category, checksum) is never reprocessed.
CREATE UNIQUE INDEX uq_upload_dedup ON upload_batches (habitation_id, category, file_checksum);
CREATE INDEX idx_upload_batches_status ON upload_batches (status);

CREATE TABLE validation_issues (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  batch_id     UUID NOT NULL REFERENCES upload_batches(id) ON DELETE CASCADE,
  row_number   INTEGER,
  field_name   VARCHAR(60),
  issue_type   VARCHAR(60) NOT NULL, -- e.g. missing_field, out_of_range, duplicate, statistical_anomaly
  severity     issue_severity NOT NULL DEFAULT 'error',
  message      TEXT NOT NULL,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_validation_issues_batch ON validation_issues (batch_id);
CREATE INDEX idx_validation_issues_type ON validation_issues (issue_type);

-- Section 13.3 (Innovation) -- reproducible, versioned scenario input snapshots.
-- Pure data groundwork for the future simulation drop; no logic reads this yet.
CREATE TABLE parameter_snapshots (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  habitation_id      UUID NOT NULL REFERENCES habitations(id) ON DELETE CASCADE,
  snapshot_label     VARCHAR(160) NOT NULL,
  payload            JSONB NOT NULL,        -- frozen copy of all 7 categories + layer refs
  source_versions    JSONB NOT NULL,        -- { demography: 3, infrastructure: 1, ... }
  is_calamity_baseline BOOLEAN NOT NULL DEFAULT false, -- Section 13.6, unused in Drop 1
  taken_by           UUID NOT NULL REFERENCES users(id),
  taken_at           TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_parameter_snapshots_habitation ON parameter_snapshots (habitation_id, taken_at DESC);
