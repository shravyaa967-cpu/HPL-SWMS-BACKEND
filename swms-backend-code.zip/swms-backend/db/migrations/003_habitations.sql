-- 003_habitations.sql
-- Section 4 (Data Model) -- TABLE: habitations

CREATE TYPE habitation_type AS ENUM ('village', 'ward', 'town', 'city');

CREATE TABLE habitations (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name         VARCHAR(160) NOT NULL,
  type         habitation_type NOT NULL,
  latitude     DECIMAL(9,6) NOT NULL,
  longitude    DECIMAL(9,6) NOT NULL,
  owner_id     UUID NOT NULL REFERENCES users(id),
  is_deleted   BOOLEAN NOT NULL DEFAULT false,
  deleted_at   TIMESTAMPTZ,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_habitations_owner ON habitations (owner_id);
CREATE INDEX idx_habitations_type ON habitations (type);
CREATE INDEX idx_habitations_not_deleted ON habitations (id) WHERE is_deleted = false;
