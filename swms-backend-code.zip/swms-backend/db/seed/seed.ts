/**
 * Seeds a starting Admin account and one sample habitation ("Shirva
 * Village", matching the design document's running example) with all
 * seven parameter categories filled in, so the API is exercisable
 * immediately after `npm run migrate && npm run seed`.
 */
import "dotenv/config";
import bcrypt from "bcrypt";
import { pool } from "../../src/config/db";

async function seed() {
  const email = process.env.SEED_ADMIN_EMAIL ?? "admin@swms.local";
  const password = process.env.SEED_ADMIN_PASSWORD ?? "ChangeMe123!";
  const passwordHash = await bcrypt.hash(password, 12);

  const client = await pool.connect();
  try {
    await client.query("BEGIN");

    const existing = await client.query("SELECT id FROM users WHERE email = $1", [email]);
    let adminId: string;
    if (existing.rows.length > 0) {
      adminId = existing.rows[0].id;
      console.log(`Admin ${email} already exists, reusing.`);
    } else {
      const res = await client.query(
        `INSERT INTO users (name, email, password_hash, role, is_active)
         VALUES ($1, $2, $3, 'admin', true) RETURNING id`,
        ["Seed Admin", email, passwordHash]
      );
      adminId = res.rows[0].id;
      console.log(`Created admin ${email} / ${password} (change this password).`);
    }

    const habRes = await client.query("SELECT id FROM habitations WHERE name = $1", ["Shirva Village"]);
    let habId: string;
    if (habRes.rows.length > 0) {
      habId = habRes.rows[0].id;
      console.log("Sample habitation already exists, reusing.");
    } else {
      const res = await client.query(
        `INSERT INTO habitations (name, type, latitude, longitude, owner_id)
         VALUES ($1, 'village', $2, $3, $4) RETURNING id`,
        ["Shirva Village", 13.3629, 74.7421, adminId]
      );
      habId = res.rows[0].id;
      console.log("Created sample habitation: Shirva Village");

      await client.query(
        `INSERT INTO demography_parameters
          (habitation_id, population, population_density_per_sq_km, growth_rate_pct,
           floating_pop_pct, household_size, literacy_pct, source, capture_method,
           confidence_score, last_verified_at, updated_by)
         VALUES ($1, 8200, 640, 1.8, 6.5, 4.6, 87.2, 'Panchayat records 2024',
           'imported', 0.80, now(), $2)`,
        [habId, adminId]
      );

      await client.query(
        `INSERT INTO infrastructure_parameters
          (habitation_id, road_coverage_pct, roads_alleys_count, residential_zone_pct,
           industrial_zone_pct, schools_count, clinics_count, collection_vehicles,
           collection_point_density_pct, existing_landfill_capacity_tonnes, updated_by)
         VALUES ($1, 62.0, 34, 70.0, 8.0, 3, 1, 2, 45.0, 500.0, $2)`,
        [habId, adminId]
      );

      await client.query(
        `INSERT INTO industrial_parameters
          (habitation_id, has_organized_industry, has_unorganized_industry,
           industrial_activity_intensity, industrial_waste_tonnes_per_day,
           hazardous_share_pct, updated_by)
         VALUES ($1, false, true, 'low', 0.4, 2.0, $2)`,
        [habId, adminId]
      );

      await client.query(
        `INSERT INTO natural_resource_parameters
          (habitation_id, annual_rainfall_mm, water_bodies_count, forest_cover_pct,
           sensitive_area_nearby, updated_by)
         VALUES ($1, 3800.0, 2, 22.0, false, $2)`,
        [habId, adminId]
      );

      await client.query(
        `INSERT INTO terrain_parameters
          (habitation_id, slope, soil_type, wind_condition, accessibility,
           flood_prone, updated_by)
         VALUES ($1, 'gentle', 'laterite', 'moderate coastal wind', 'high', true, $2)`,
        [habId, adminId]
      );

      await client.query(
        `INSERT INTO economic_parameters
          (habitation_id, per_capita_income_annual, annual_budget_inr,
           willingness_to_pay_pct, cost_constraint_level, updated_by)
         VALUES ($1, 145000.0, 3200000.0, 55.0, 'moderate', $2)`,
        [habId, adminId]
      );

      await client.query(
        `INSERT INTO cultural_parameters
          (habitation_id, diet_type, segregation_adherence_pct, festival_spike_pct,
           local_practice_notes, updated_by)
         VALUES ($1, 'mixed', 40.0, 30.0, 'Heavy organic waste spike during Krishna Janmashtami and temple festivals.', $2)`,
        [habId, adminId]
      );
    }

    await client.query("COMMIT");
    console.log("Seed complete.");
  } catch (err) {
    await client.query("ROLLBACK");
    console.error("Seed failed:", err);
    process.exitCode = 1;
  } finally {
    client.release();
    await pool.end();
  }
}

seed();
