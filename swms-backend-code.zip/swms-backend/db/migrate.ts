/**
 * Minimal, dependency-light SQL migration runner.
 * Applies every .sql file in db/migrations, in filename order, inside a
 * transaction each, and records applied filenames in schema_migrations
 * so re-running `npm run migrate` is a safe no-op.
 *
 * Usage:
 *   npm run migrate         -> applies all pending migrations
 *   npm run migrate:down    -> drops the whole public schema (dev reset only)
 */
import fs from "fs";
import path from "path";
import "dotenv/config";
import { Pool } from "pg";

const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const MIGRATIONS_DIR = path.join(__dirname, "migrations");

async function ensureMigrationsTable() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS schema_migrations (
      filename VARCHAR(255) PRIMARY KEY,
      applied_at TIMESTAMPTZ NOT NULL DEFAULT now()
    );
  `);
}

async function up() {
  await ensureMigrationsTable();
  const files = fs
    .readdirSync(MIGRATIONS_DIR)
    .filter((f) => f.endsWith(".sql"))
    .sort();

  const { rows } = await pool.query<{ filename: string }>("SELECT filename FROM schema_migrations");
  const applied = new Set(rows.map((r) => r.filename));

  for (const file of files) {
    if (applied.has(file)) {
      console.log(`skip  ${file} (already applied)`);
      continue;
    }
    const sql = fs.readFileSync(path.join(MIGRATIONS_DIR, file), "utf-8");
    const client = await pool.connect();
    try {
      await client.query("BEGIN");
      await client.query(sql);
      await client.query("INSERT INTO schema_migrations (filename) VALUES ($1)", [file]);
      await client.query("COMMIT");
      console.log(`OK    ${file}`);
    } catch (err) {
      await client.query("ROLLBACK");
      console.error(`FAIL  ${file}`);
      throw err;
    } finally {
      client.release();
    }
  }
  console.log("All migrations applied.");
}

async function down() {
  // Dev-only convenience: drop and recreate the public schema.
  console.log("Dropping public schema (dev reset)...");
  await pool.query("DROP SCHEMA public CASCADE; CREATE SCHEMA public;");
  console.log("Schema dropped. Run `npm run migrate` to rebuild.");
}

async function main() {
  const cmd = process.argv[2] ?? "up";
  if (cmd === "up") await up();
  else if (cmd === "down") await down();
  else {
    console.error(`Unknown command: ${cmd}. Use "up" or "down".`);
    process.exit(1);
  }
  await pool.end();
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
