import { Request, Response, NextFunction } from "express";
import { AppError } from "../utils/appError";

export type Role = "admin" | "planner" | "researcher";

/**
 * Section 7 -- RBAC Matrix (summary):
 *   admin      - full CRUD on users, habitations, all 7 parameter
 *                categories, GIS layers, uploads; sees all habitations.
 *   planner    - CRUD on habitations they own + linked parameters/GIS
 *                layers/uploads; cannot manage users.
 *   researcher - read-only everywhere (GET only), including validation
 *                reports and the data-quality dashboard (Section 13.4).
 *
 * requireRole() checks the coarse role gate; requireOwnershipOrAdmin()
 * (in habitations.service.ts) checks the fine-grained "planner may only
 * write their own habitation" rule.
 */
export function requireRole(...allowed: Role[]) {
  return (req: Request, _res: Response, next: NextFunction) => {
    if (!req.user) return next(AppError.unauthorized());
    if (!allowed.includes(req.user.role)) {
      return next(AppError.forbidden(`This action requires one of: ${allowed.join(", ")}`));
    }
    next();
  };
}

/** Convenience gate: researchers are read-only system-wide. */
export function blockResearcherWrite(req: Request, _res: Response, next: NextFunction) {
  if (req.user?.role === "researcher") {
    return next(AppError.forbidden("Researcher accounts are read-only"));
  }
  next();
}
