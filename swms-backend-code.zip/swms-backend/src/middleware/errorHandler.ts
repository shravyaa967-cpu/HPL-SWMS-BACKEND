import { Request, Response, NextFunction } from "express";
import { AppError } from "../utils/appError";
import { logger } from "../config/logger";

export function notFoundHandler(req: Request, _res: Response, next: NextFunction) {
  next(AppError.notFound(`No route: ${req.method} ${req.originalUrl}`));
}

// eslint-disable-next-line @typescript-eslint/no-unused-vars
export function errorHandler(err: unknown, req: Request, res: Response, _next: NextFunction) {
  if (err instanceof AppError) {
    if (err.status >= 500) {
      logger.error(err.message, { requestId: req.requestId, code: err.code, stack: err.stack });
    }
    return res.status(err.status).json({
      success: false,
      error: { code: err.code, message: err.message, details: err.details },
      requestId: req.requestId,
    });
  }

  // Postgres unique-violation -> 409 Conflict, mapped generically so
  // callers never see a raw database error.
  const pgErr = err as { code?: string; constraint?: string };
  if (pgErr?.code === "23505") {
    return res.status(409).json({
      success: false,
      error: { code: "CONFLICT", message: "A record with the same unique value already exists." },
      requestId: req.requestId,
    });
  }

  logger.error("Unhandled error", {
    requestId: req.requestId,
    message: (err as Error)?.message,
    stack: (err as Error)?.stack,
  });
  return res.status(500).json({
    success: false,
    error: { code: "INTERNAL_ERROR", message: "Something went wrong. Please try again." },
    requestId: req.requestId,
  });
}
