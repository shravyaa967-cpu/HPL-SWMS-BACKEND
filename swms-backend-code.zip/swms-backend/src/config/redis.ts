import IORedis from "ioredis";
import { env } from "./env";

/**
 * Shared IORedis connection for BullMQ. Only instantiated when
 * USE_REDIS_QUEUE=true; see src/queue/queue.ts for the automatic
 * fallback to an in-process worker_threads queue when Redis is not
 * available (Addendum: "Background Processing Without Redis").
 */
export const redisConnection = env.useRedisQueue
  ? new IORedis(env.redisUrl, { maxRetriesPerRequest: null })
  : null;
