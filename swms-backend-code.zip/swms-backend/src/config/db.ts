import { Pool, PoolClient } from "pg";
import { env } from "./env";

export const pool = new Pool({
  connectionString: env.databaseUrl,
  max: 10,
  idleTimeoutMillis: 30000,
});

pool.on("error", (err) => {
  // A truly unexpected error on an idle client -- log and let the
  // process supervisor (pm2/systemd/k8s) decide whether to restart.
  console.error("Unexpected PostgreSQL pool error", err);
});

/**
 * Runs `fn` inside a single transaction. BR-03 (parameter change log)
 * and several other rules in Section 5 rely on multi-statement writes
 * being atomic, so this helper is used anywhere more than one write
 * must succeed or fail together.
 */
export async function withTransaction<T>(fn: (client: PoolClient) => Promise<T>): Promise<T> {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const result = await fn(client);
    await client.query("COMMIT");
    return result;
  } catch (err) {
    await client.query("ROLLBACK");
    throw err;
  } finally {
    client.release();
  }
}
