import { readBuffer } from "../../utils/storage";
import { processGisUpload } from "../../modules/mapLayers/mapLayers.service";
import { registerHandler } from "../queue";
import { logger } from "../../config/logger";

registerHandler("gis-normalization", async (data) => {
  logger.info("Processing GIS normalization job", { placeholderId: data.placeholderId });
  const fileBuffer = readBuffer(data.storageKey);
  await processGisUpload({ ...data, fileBuffer });
});
