import { pool } from "../../config/db";
import { readBuffer } from "../../utils/storage";
import { normalizeAndValidateCsv } from "../../modules/uploads/validators/normalize";
import { applyValidatedRows } from "../../modules/uploads/uploads.service";
import { registerHandler } from "../queue";
import { logger } from "../../config/logger";

registerHandler("dataset-validation", async (data: { batchId: string }) => {
  logger.info("Processing dataset validation job", { batchId: data.batchId });

  const { rows } = await pool.query("SELECT * FROM upload_batches WHERE id = $1", [data.batchId]);
  const batch = rows[0];
  if (!batch) {
    logger.warn("Upload batch not found for validation job", { batchId: data.batchId });
    return;
  }

  await pool.query("UPDATE upload_batches SET status = 'validating' WHERE id = $1", [batch.id]);

  try {
    const fileBuffer = readBuffer(batch.storage_key);
    const { validRows, issues } = await normalizeAndValidateCsv(batch.category, batch.habitation_id, fileBuffer);

    for (const issue of issues) {
      await pool.query(
        `INSERT INTO validation_issues (batch_id, row_number, field_name, issue_type, severity, message)
         VALUES ($1, $2, $3, $4, $5, $6)`,
        [batch.id, issue.rowNumber, issue.fieldName ?? null, issue.issueType, issue.severity, issue.message]
      );
    }

    const errorCount = issues.filter((i) => i.severity === "error").length;
    const warningCount = issues.filter((i) => i.severity === "warning").length;

    if (validRows.length > 0) {
      await applyValidatedRows(batch.category, batch.habitation_id, validRows, batch.uploaded_by);
    }

    const status = errorCount === 0 ? "validated" : validRows.length > 0 ? "partially_validated" : "failed";

    await pool.query(
      `UPDATE upload_batches
       SET status = $2, row_count = $3, error_count = $4, warning_count = $5, processed_at = now()
       WHERE id = $1`,
      [batch.id, status, validRows.length + errorCount, errorCount, warningCount]
    );
  } catch (err) {
    logger.error("Dataset validation job failed", { batchId: batch.id, error: (err as Error).message });
    await pool.query(
      "UPDATE upload_batches SET status = 'failed', processed_at = now() WHERE id = $1",
      [batch.id]
    );
  }
});
