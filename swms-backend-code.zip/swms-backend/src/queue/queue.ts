import { Queue, Worker, Job } from "bullmq";
import { env } from "../config/env";
import { redisConnection } from "../config/redis";
import { logger } from "../config/logger";

/**
 * Addendum: "Background Processing Without Redis" -- BullMQ/Redis is
 * the primary design (Section 3, Technical Stack) for GIS normalization
 * and upload validation jobs, because those are exactly the
 * CPU/IO-bound, retryable, at-least-once background jobs BullMQ is
 * built for. However a student environment may not always have Redis
 * running, so this module exposes one enqueue() function with two
 * interchangeable implementations chosen by USE_REDIS_QUEUE, keeping
 * the calling code (uploads/mapLayers services) identical either way.
 */

export type JobName = "gis-normalization" | "dataset-validation";

type Handler = (data: any) => Promise<void>;

const handlers = new Map<JobName, Handler>();
export function registerHandler(name: JobName, handler: Handler) {
  handlers.set(name, handler);
}

let bullQueue: Queue | null = null;
if (env.useRedisQueue && redisConnection) {
  bullQueue = new Queue("swms-jobs", { connection: redisConnection as any });
}

// In-process fallback: a tiny sequential queue so the API never blocks
// the HTTP response, without requiring Redis. Not durable across
// process restarts -- acceptable for a Drop-1 student prototype and
// clearly documented as a fallback, not the primary design.
const fallbackQueue: Array<{ name: JobName; data: any }> = [];
let fallbackRunning = false;

async function drainFallbackQueue() {
  if (fallbackRunning) return;
  fallbackRunning = true;
  while (fallbackQueue.length > 0) {
    const job = fallbackQueue.shift()!;
    const handler = handlers.get(job.name);
    try {
      if (handler) await handler(job.data);
    } catch (err) {
      logger.error(`Fallback job "${job.name}" failed`, { error: (err as Error).message });
    }
  }
  fallbackRunning = false;
}

export async function enqueue(name: JobName, data: any) {
  if (bullQueue) {
    await bullQueue.add(name, data, {
      attempts: 3,
      backoff: { type: "exponential", delay: 2000 },
      removeOnComplete: 100,
      removeOnFail: 500,
    });
  } else {
    fallbackQueue.push({ name, data });
    setImmediate(drainFallbackQueue);
  }
}

/** Called once from src/worker.ts (BullMQ path only -- the fallback
 * path processes jobs inline in the API process). */
export function startBullWorkers() {
  if (!bullQueue || !redisConnection) return;
  const worker = new Worker(
    "swms-jobs",
    async (job: Job) => {
      const handler = handlers.get(job.name as JobName);
      if (!handler) throw new Error(`No handler registered for job "${job.name}"`);
      await handler(job.data);
    },
    { connection: redisConnection as any, concurrency: 4 }
  );
  worker.on("failed", (job, err) => {
    logger.error(`Job ${job?.id} (${job?.name}) failed`, { error: err.message });
  });
  logger.info("BullMQ worker started");
  return worker;
}

export const usingRedisQueue = !!bullQueue;
