import { app } from "./app";
import { env } from "./config/env";
import { logger } from "./config/logger";
import { usingRedisQueue } from "./queue/queue";

// Registers job handlers. When USE_REDIS_QUEUE=false these run inline
// in this same process (see src/queue/queue.ts fallback path) so the
// API is fully functional without a separate `npm run worker` process.
import "./queue/jobs/gisNormalization.job";
import "./queue/jobs/datasetValidation.job";

app.listen(env.port, () => {
  logger.info(`SWMS backend listening on port ${env.port}`, {
    env: env.nodeEnv,
    queue: usingRedisQueue ? "redis/bullmq" : "in-process fallback",
  });
});
