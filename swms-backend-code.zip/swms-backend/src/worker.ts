/**
 * Standalone worker process for the Redis/BullMQ path. Run this
 * alongside `npm run dev` when USE_REDIS_QUEUE=true so GIS
 * normalization and dataset validation jobs are processed out of the
 * request/response cycle, matching Section 3's "Redis / BullMQ"
 * technical-stack decision. If USE_REDIS_QUEUE=false, this process
 * exits immediately -- the API server already processes jobs inline.
 */
import { env } from "./config/env";
import { logger } from "./config/logger";
import { startBullWorkers } from "./queue/queue";

import "./queue/jobs/gisNormalization.job";
import "./queue/jobs/datasetValidation.job";

if (!env.useRedisQueue) {
  logger.warn("USE_REDIS_QUEUE=false -- nothing for this worker process to do. The API server handles jobs inline.");
  process.exit(0);
}

startBullWorkers();
logger.info("Worker process running. Waiting for jobs...");
