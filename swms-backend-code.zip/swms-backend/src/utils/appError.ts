/**
 * A single error class used throughout the app. errorHandler.ts
 * catches these (and anything else) and formats them into the
 * standard error envelope from Section 6.
 */
export class AppError extends Error {
  status: number;
  code: string;
  details?: unknown;

  constructor(status: number, code: string, message: string, details?: unknown) {
    super(message);
    this.status = status;
    this.code = code;
    this.details = details;
  }

  static badRequest(message: string, details?: unknown) {
    return new AppError(400, "BAD_REQUEST", message, details);
  }
  static unauthorized(message = "Authentication required") {
    return new AppError(401, "UNAUTHORIZED", message);
  }
  static forbidden(message = "You do not have permission to perform this action") {
    return new AppError(403, "FORBIDDEN", message);
  }
  static notFound(message = "Resource not found") {
    return new AppError(404, "NOT_FOUND", message);
  }
  static conflict(message: string, details?: unknown) {
    return new AppError(409, "CONFLICT", message, details);
  }
  static unprocessable(message: string, details?: unknown) {
    return new AppError(422, "UNPROCESSABLE_ENTITY", message, details);
  }
  static tooLarge(message = "Uploaded file exceeds the maximum allowed size") {
    return new AppError(413, "PAYLOAD_TOO_LARGE", message);
  }
  static internal(message = "Internal server error") {
    return new AppError(500, "INTERNAL_ERROR", message);
  }
}
