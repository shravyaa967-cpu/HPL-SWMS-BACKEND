import crypto from "crypto";

/** BR-07: identical file content (by SHA-256) for the same habitation
 * + category is treated as a duplicate upload and rejected before any
 * processing job is enqueued. */
export function sha256(buffer: Buffer): string {
  return crypto.createHash("sha256").update(buffer).digest("hex");
}
