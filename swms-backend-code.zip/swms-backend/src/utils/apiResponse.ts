import { Response } from "express";

/**
 * Section 6 (API Design Principles) -- every response uses one
 * consistent envelope so frontend/mobile clients never need to branch
 * on shape:
 *   { success: true,  data: ..., meta?: {...} }
 *   { success: false, error: { code, message, details? } }
 */
export function ok<T>(res: Response, data: T, status = 200, meta?: Record<string, unknown>) {
  return res.status(status).json(meta ? { success: true, data, meta } : { success: true, data });
}

export function created<T>(res: Response, data: T) {
  return ok(res, data, 201);
}

export function noContent(res: Response) {
  return res.status(204).send();
}

export function paginated<T>(
  res: Response,
  items: T[],
  page: number,
  pageSize: number,
  totalCount: number
) {
  return ok(res, items, 200, {
    pagination: {
      page,
      pageSize,
      totalCount,
      totalPages: Math.max(1, Math.ceil(totalCount / pageSize)),
    },
  });
}
