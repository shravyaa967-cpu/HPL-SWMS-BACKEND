import fs from "fs";
import path from "path";
import { env } from "../config/env";

/**
 * Local-disk implementation of the upload storage interface. Swap this
 * file for an S3-compatible client in production; every caller only
 * depends on saveBuffer()/readBuffer()/keyToUrl(), never on the
 * filesystem directly, so the storage backend is a one-file change.
 */
fs.mkdirSync(env.uploadStorageDir, { recursive: true });

export function saveBuffer(buffer: Buffer, filename: string): { storageKey: string; url: string } {
  const safeName = `${Date.now()}-${filename.replace(/[^a-zA-Z0-9._-]/g, "_")}`;
  const fullPath = path.join(env.uploadStorageDir, safeName);
  fs.writeFileSync(fullPath, buffer);
  return { storageKey: safeName, url: keyToUrl(safeName) };
}

export function readBuffer(storageKey: string): Buffer {
  return fs.readFileSync(path.join(env.uploadStorageDir, storageKey));
}

export function keyToUrl(storageKey: string): string {
  return `/uploads-storage/${storageKey}`;
}
