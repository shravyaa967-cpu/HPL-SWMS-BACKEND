declare module "shpjs" {
  function shp(buffer: Buffer | ArrayBuffer): Promise<GeoJSON.FeatureCollection | GeoJSON.FeatureCollection[]>;
  export default shp;
}
