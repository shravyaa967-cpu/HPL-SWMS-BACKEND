import express from "express";
import cors from "cors";
import helmet from "helmet";
import compression from "compression";
import morgan from "morgan";
import path from "path";
import { env } from "./config/env";
import { requestId } from "./middleware/requestId";
import { notFoundHandler, errorHandler } from "./middleware/errorHandler";
import { ok } from "./utils/apiResponse";

// Registers background job handlers (see src/queue/queue.ts). Imported
// here -- not only in server.ts -- so the in-process fallback queue
// works correctly for anything that imports this app module directly
// (e.g. the test suite), independent of whether a separate `npm run
// worker` process is also running for the Redis/BullMQ path.
import "./queue/jobs/gisNormalization.job";
import "./queue/jobs/datasetValidation.job";


import authRoutes from "./modules/auth/auth.routes";
import usersRoutes from "./modules/users/users.routes";
import habitationsRoutes from "./modules/habitations/habitations.routes";
import parametersRoutes from "./modules/parameters/parameters.routes";
import mapLayersRoutes from "./modules/mapLayers/mapLayers.routes";
import uploadsRoutes from "./modules/uploads/uploads.routes";
import dataQualityRoutes from "./modules/dataQuality/dataQuality.routes";
import snapshotsRoutes from "./modules/snapshots/snapshots.routes";

export const app = express();

app.use(helmet());
app.use(cors({ origin: env.corsOrigin }));
app.use(compression());
app.use(express.json({ limit: "2mb" }));
app.use(requestId);
if (env.nodeEnv !== "test") {
  app.use(morgan(":method :url :status :response-time ms - :res[content-length]"));
}

// Serves original uploaded GIS/spreadsheet files back for audit/download.
app.use("/uploads-storage", express.static(path.resolve(env.uploadStorageDir)));

app.get("/health", (_req, res) => ok(res, { status: "ok", timestamp: new Date().toISOString() }));

app.use("/api/auth", authRoutes);
app.use("/api/users", usersRoutes);
app.use("/api/habitations", habitationsRoutes);
// Data-quality summary and scenario snapshots are additional routes
// nested logically under /api/habitations/:id/... (Section 13).
app.use("/api/habitations", dataQualityRoutes);
app.use("/api/habitations", snapshotsRoutes);
app.use("/api/parameters", parametersRoutes);
app.use("/api/habitations", mapLayersRoutes); // /:habitationId/layers, /batches/:batchId/status
app.use("/api/uploads", uploadsRoutes);

app.use(notFoundHandler);
app.use(errorHandler);
