import { Request, Response, NextFunction } from "express";
import { ok, created, noContent, paginated } from "../../utils/apiResponse";
import * as svc from "./habitations.service";

export async function list(req: Request, res: Response, next: NextFunction) {
  try {
    const { page, pageSize, type, search } = req.query as unknown as {
      page: number;
      pageSize: number;
      type?: string;
      search?: string;
    };
    const { rows, totalCount } = await svc.listHabitations({ page, pageSize, type, search, user: req.user! });
    return paginated(res, rows, page, pageSize, totalCount);
  } catch (err) {
    next(err);
  }
}

export async function getOne(req: Request, res: Response, next: NextFunction) {
  try {
    const habitation = await svc.getHabitationOr404(req.params.id);
    return ok(res, habitation);
  } catch (err) {
    next(err);
  }
}

export async function create(req: Request, res: Response, next: NextFunction) {
  try {
    if (req.user!.role === "researcher") throw Object.assign(new Error(), { status: 403 });
    const habitation = await svc.createHabitation({ ...req.body, ownerId: req.user!.sub });
    return created(res, habitation);
  } catch (err) {
    next(err);
  }
}

export async function update(req: Request, res: Response, next: NextFunction) {
  try {
    const existing = await svc.getHabitationOr404(req.params.id);
    svc.assertCanWrite(existing, req.user!);
    const updated = await svc.updateHabitation(req.params.id, req.body);
    return ok(res, updated);
  } catch (err) {
    next(err);
  }
}

export async function remove(req: Request, res: Response, next: NextFunction) {
  try {
    const existing = await svc.getHabitationOr404(req.params.id);
    svc.assertCanWrite(existing, req.user!);
    await svc.softDeleteHabitation(req.params.id);
    return noContent(res);
  } catch (err) {
    next(err);
  }
}
