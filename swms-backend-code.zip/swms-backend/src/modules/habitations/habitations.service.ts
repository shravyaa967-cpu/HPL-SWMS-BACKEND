import { pool } from "../../config/db";
import { AppError } from "../../utils/appError";
import { AccessTokenPayload } from "../../utils/jwt";

export interface Habitation {
  id: string;
  name: string;
  type: "village" | "ward" | "town" | "city";
  latitude: string;
  longitude: string;
  owner_id: string;
  created_at: string;
  updated_at: string;
}

export async function listHabitations(opts: {
  page: number;
  pageSize: number;
  type?: string;
  search?: string;
  user: AccessTokenPayload;
}) {
  const conditions: string[] = ["is_deleted = false"];
  const params: unknown[] = [];

  // Planners see only their own habitations; admin/researcher see all
  // (researcher is read-only but system-wide, per the RBAC matrix).
  if (opts.user.role === "planner") {
    params.push(opts.user.sub);
    conditions.push(`owner_id = $${params.length}`);
  }
  if (opts.type) {
    params.push(opts.type);
    conditions.push(`type = $${params.length}`);
  }
  if (opts.search) {
    params.push(`%${opts.search}%`);
    conditions.push(`name ILIKE $${params.length}`);
  }

  const whereClause = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";
  const countRes = await pool.query<{ count: string }>(
    `SELECT COUNT(*)::text AS count FROM habitations ${whereClause}`,
    params
  );
  const totalCount = parseInt(countRes.rows[0].count, 10);

  const offset = (opts.page - 1) * opts.pageSize;
  params.push(opts.pageSize, offset);
  const { rows } = await pool.query<Habitation>(
    `SELECT * FROM habitations ${whereClause} ORDER BY created_at DESC LIMIT $${params.length - 1} OFFSET $${params.length}`,
    params
  );

  return { rows, totalCount };
}

export async function getHabitationOr404(id: string): Promise<Habitation> {
  const { rows } = await pool.query<Habitation>(
    "SELECT * FROM habitations WHERE id = $1 AND is_deleted = false",
    [id]
  );
  if (rows.length === 0) throw AppError.notFound("Habitation not found");
  return rows[0];
}

export function assertCanWrite(habitation: Habitation, user: AccessTokenPayload) {
  if (user.role === "researcher") throw AppError.forbidden("Researcher accounts are read-only");
  if (user.role === "planner" && habitation.owner_id !== user.sub) {
    throw AppError.forbidden("Planners may only modify habitations they own");
  }
}

export async function createHabitation(input: {
  name: string;
  type: string;
  latitude: number;
  longitude: number;
  ownerId: string;
}) {
  const { rows } = await pool.query<Habitation>(
    `INSERT INTO habitations (name, type, latitude, longitude, owner_id)
     VALUES ($1, $2, $3, $4, $5) RETURNING *`,
    [input.name, input.type, input.latitude, input.longitude, input.ownerId]
  );
  return rows[0];
}

export async function updateHabitation(
  id: string,
  patch: Partial<{ name: string; type: string; latitude: number; longitude: number }>
) {
  const fields = Object.entries(patch).filter(([, v]) => v !== undefined);
  if (fields.length === 0) return getHabitationOr404(id);

  const setClauses = fields.map(([key], i) => `${key} = $${i + 2}`);
  const values = fields.map(([, v]) => v);
  const { rows } = await pool.query<Habitation>(
    `UPDATE habitations SET ${setClauses.join(", ")}, updated_at = now()
     WHERE id = $1 AND is_deleted = false RETURNING *`,
    [id, ...values]
  );
  if (rows.length === 0) throw AppError.notFound("Habitation not found");
  return rows[0];
}

/** Soft delete (Section 4 note: habitations use soft delete so history/
 * change-log/GIS references remain valid for audit purposes). */
export async function softDeleteHabitation(id: string) {
  const { rows } = await pool.query(
    "UPDATE habitations SET is_deleted = true, deleted_at = now() WHERE id = $1 AND is_deleted = false RETURNING id",
    [id]
  );
  if (rows.length === 0) throw AppError.notFound("Habitation not found");
}
