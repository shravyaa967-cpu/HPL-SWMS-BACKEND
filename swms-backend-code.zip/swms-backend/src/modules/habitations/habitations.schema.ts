import { z } from "zod";

export const createHabitationSchema = z.object({
  body: z.object({
    name: z.string().min(2).max(160),
    type: z.enum(["village", "ward", "town", "city"]),
    latitude: z.number().min(-90).max(90),
    longitude: z.number().min(-180).max(180),
  }),
  query: z.object({}).optional(),
  params: z.object({}).optional(),
});

export const updateHabitationSchema = z.object({
  body: z.object({
    name: z.string().min(2).max(160).optional(),
    type: z.enum(["village", "ward", "town", "city"]).optional(),
    latitude: z.number().min(-90).max(90).optional(),
    longitude: z.number().min(-180).max(180).optional(),
  }),
  query: z.object({}).optional(),
  params: z.object({ id: z.string().uuid() }),
});

export const listHabitationsSchema = z.object({
  body: z.object({}).optional(),
  query: z.object({
    page: z.coerce.number().int().min(1).default(1),
    pageSize: z.coerce.number().int().min(1).max(100).default(20),
    type: z.enum(["village", "ward", "town", "city"]).optional(),
    search: z.string().max(160).optional(),
  }),
  params: z.object({}).optional(),
});
