import { Router } from "express";
import { authenticate } from "../../middleware/auth";
import { validate } from "../../middleware/validate";
import { createHabitationSchema, updateHabitationSchema, listHabitationsSchema } from "./habitations.schema";
import * as ctrl from "./habitations.controller";

const router = Router();
router.use(authenticate);

router.get("/", validate(listHabitationsSchema), ctrl.list);
router.post("/", validate(createHabitationSchema), ctrl.create);
router.get("/:id", ctrl.getOne);
router.put("/:id", validate(updateHabitationSchema), ctrl.update);
router.delete("/:id", ctrl.remove);

export default router;
