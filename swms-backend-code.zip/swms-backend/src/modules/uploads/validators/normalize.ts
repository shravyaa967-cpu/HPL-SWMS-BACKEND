import { parse } from "csv-parse/sync";
import { ZodObject } from "zod";
import { CATEGORY_REGISTRY, CategorySlug, toSnakeCase } from "../../parameters/parameter.categories";
import { pool } from "../../../config/db";

export interface RowIssue {
  rowNumber: number;
  fieldName?: string;
  issueType: string;
  severity: "error" | "warning";
  message: string;
}

export interface NormalizeResult {
  validRows: Array<{ rowNumber: number; data: Record<string, unknown> }>;
  issues: RowIssue[];
}

/**
 * Section 3.D (Validation & Normalization). Steps, in order, per row:
 *   1. Missing/incorrect value detection (BR-05/BR-06: required fields,
 *      type coercion, range checks) via each category's own Zod schema
 *   2. Normalization into the same internal camelCase shape the
 *      /parameters PUT endpoint accepts, so both entry paths (manual
 *      form vs. spreadsheet upload) converge on one write path
 *   3. Section 13.5 (Innovation): a statistical-anomaly check against
 *      the habitation's own historical values for numeric fields,
 *      recorded as a "warning" (does not block validation) rather than
 *      an "error"
 */
export async function normalizeAndValidateCsv(
  category: CategorySlug,
  habitationId: string,
  csvBuffer: Buffer
): Promise<NormalizeResult> {
  const schema = CATEGORY_REGISTRY[category].schema as ZodObject<any>;
  const records: Record<string, string>[] = parse(csvBuffer, {
    columns: true,
    skip_empty_lines: true,
    trim: true,
  });

  const validRows: NormalizeResult["validRows"] = [];
  const issues: RowIssue[] = [];

  for (let i = 0; i < records.length; i++) {
    const rowNumber = i + 2; // account for the header row, 1-indexed for humans
    const raw = records[i];

    const coerced = coerceTypes(raw);
    const result = schema.safeParse(coerced);

    if (!result.success) {
      for (const issue of result.error.issues) {
        issues.push({
          rowNumber,
          fieldName: issue.path.join("."),
          issueType: "invalid_value",
          severity: "error",
          message: issue.message,
        });
      }
      continue;
    }

    await checkStatisticalAnomalies(category, habitationId, rowNumber, result.data, issues);
    validRows.push({ rowNumber, data: result.data });
  }

  return { validRows, issues };
}

function coerceTypes(row: Record<string, string>): Record<string, unknown> {
  const out: Record<string, unknown> = {};
  for (const [key, value] of Object.entries(row)) {
    if (value === "" || value === undefined) continue;
    if (value === "true" || value === "false") {
      out[key] = value === "true";
    } else if (!isNaN(Number(value)) && value.trim() !== "") {
      out[key] = Number(value);
    } else {
      out[key] = value;
    }
  }
  return out;
}

/** Section 13.5 -- flags (does not reject) values >3 standard deviations
 * from this habitation's own historical values for the same field. */
async function checkStatisticalAnomalies(
  category: CategorySlug,
  habitationId: string,
  rowNumber: number,
  data: Record<string, unknown>,
  issues: RowIssue[]
) {
  const { rows } = await pool.query(
    `SELECT field_name, new_value FROM parameter_change_log
     WHERE habitation_id = $1 AND category = $2 AND field_name = ANY($3)`,
    [habitationId, category, Object.keys(data).map(toSnakeCase)]
  );

  const historyByField = new Map<string, number[]>();
  for (const row of rows) {
    const num = Number(row.new_value);
    if (Number.isNaN(num)) continue;
    const arr = historyByField.get(row.field_name) ?? [];
    arr.push(num);
    historyByField.set(row.field_name, arr);
  }

  for (const [field, value] of Object.entries(data)) {
    if (typeof value !== "number") continue;
    const history = historyByField.get(toSnakeCase(field));
    if (!history || history.length < 3) continue; // not enough history to judge

    const mean = history.reduce((a, b) => a + b, 0) / history.length;
    const variance = history.reduce((a, b) => a + (b - mean) ** 2, 0) / history.length;
    const stdDev = Math.sqrt(variance);
    if (stdDev === 0) continue;

    if (Math.abs(value - mean) > 3 * stdDev) {
      issues.push({
        rowNumber,
        fieldName: field,
        issueType: "statistical_anomaly",
        severity: "warning",
        message: `${field}=${value} is more than 3 standard deviations from this habitation's historical average (${mean.toFixed(2)}). Flagged for review, not rejected.`,
      });
    }
  }
}
