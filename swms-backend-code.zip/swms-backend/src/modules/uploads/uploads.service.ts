import { pool } from "../../config/db";
import { AppError } from "../../utils/appError";
import { sha256 } from "../../utils/checksum";
import { saveBuffer } from "../../utils/storage";
import { enqueue } from "../../queue/queue";
import { upsertParameter } from "../parameters/parameters.service";
import { CategorySlug } from "../parameters/parameter.categories";

export async function createUploadBatch(input: {
  habitationId: string;
  category: CategorySlug;
  file: { buffer: Buffer; originalname: string };
  uploadedBy: string;
}) {
  const checksum = sha256(input.file.buffer);

  // BR-07: identical (habitation, category, checksum) is a duplicate --
  // reject before any storage write or job is enqueued.
  const existing = await pool.query(
    "SELECT id, status FROM upload_batches WHERE habitation_id = $1 AND category = $2 AND file_checksum = $3",
    [input.habitationId, input.category, checksum]
  );
  if (existing.rows.length > 0) {
    throw AppError.conflict("This exact file has already been uploaded for this habitation and category.", {
      existingBatchId: existing.rows[0].id,
      status: existing.rows[0].status,
    });
  }

  const { storageKey } = saveBuffer(input.file.buffer, input.file.originalname);

  const { rows } = await pool.query(
    `INSERT INTO upload_batches
       (habitation_id, target_type, category, original_filename, file_checksum, storage_key, status, uploaded_by)
     VALUES ($1, 'parameter', $2, $3, $4, $5, 'pending', $6)
     RETURNING *`,
    [input.habitationId, input.category, input.file.originalname, checksum, storageKey, input.uploadedBy]
  );
  const batch = rows[0];

  await enqueue("dataset-validation", { batchId: batch.id });
  return batch;
}

export async function getBatch(id: string) {
  const { rows } = await pool.query("SELECT * FROM upload_batches WHERE id = $1", [id]);
  if (rows.length === 0) throw AppError.notFound("Upload batch not found");
  return rows[0];
}

export async function getIssuesForBatch(batchId: string) {
  const { rows } = await pool.query(
    "SELECT * FROM validation_issues WHERE batch_id = $1 ORDER BY row_number ASC",
    [batchId]
  );
  return rows;
}

/** Section 13.4 -- Validation & Data-Quality Dashboard (read-only
 * aggregation over data the validation pipeline already writes). */
export async function getValidationDashboard(habitationId: string) {
  const byCategory = await pool.query(
    `SELECT b.category,
            COUNT(*) FILTER (WHERE vi.severity = 'error')   AS error_count,
            COUNT(*) FILTER (WHERE vi.severity = 'warning') AS warning_count
     FROM upload_batches b
     LEFT JOIN validation_issues vi ON vi.batch_id = b.id
     WHERE b.habitation_id = $1
     GROUP BY b.category`,
    [habitationId]
  );

  const topIssueTypes = await pool.query(
    `SELECT vi.issue_type, COUNT(*) AS occurrences
     FROM validation_issues vi
     JOIN upload_batches b ON b.id = vi.batch_id
     WHERE b.habitation_id = $1
     GROUP BY vi.issue_type
     ORDER BY occurrences DESC
     LIMIT 5`,
    [habitationId]
  );

  const recentBatches = await pool.query(
    `SELECT id, category, status, error_count, warning_count, uploaded_at
     FROM upload_batches WHERE habitation_id = $1
     ORDER BY uploaded_at DESC LIMIT 10`,
    [habitationId]
  );

  return {
    byCategory: byCategory.rows,
    topIssueTypes: topIssueTypes.rows,
    recentBatches: recentBatches.rows,
  };
}

/** Executed by the background worker once a batch has been validated:
 * writes every row that passed validation through the same
 * upsertParameter() path a manual PUT would use. Rows with an "error"
 * severity issue are skipped; "warning" (e.g. statistical_anomaly)
 * rows are still applied. */
export async function applyValidatedRows(
  category: CategorySlug,
  habitationId: string,
  rows: Array<{ data: Record<string, unknown> }>,
  uploadedBy: string
) {
  for (const row of rows) {
    await upsertParameter(category, habitationId, row.data, uploadedBy);
  }
}
