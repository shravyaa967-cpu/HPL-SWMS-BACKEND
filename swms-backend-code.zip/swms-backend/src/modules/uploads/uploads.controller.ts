import { Request, Response, NextFunction } from "express";
import { ok, created } from "../../utils/apiResponse";
import { AppError } from "../../utils/appError";
import { getHabitationOr404, assertCanWrite } from "../habitations/habitations.service";
import { assertValidCategory } from "../parameters/parameters.service";
import * as svc from "./uploads.service";

export async function uploadBatch(req: Request, res: Response, next: NextFunction) {
  try {
    const habitation = await getHabitationOr404(req.params.habitationId);
    assertCanWrite(habitation, req.user!);

    const category = req.body.category as string;
    assertValidCategory(category);
    if (!req.file) throw AppError.badRequest("No file uploaded (field name: file)");

    const batch = await svc.createUploadBatch({
      habitationId: habitation.id,
      category,
      file: { buffer: req.file.buffer, originalname: req.file.originalname },
      uploadedBy: req.user!.sub,
    });
    return created(res, batch);
  } catch (err) {
    next(err);
  }
}

export async function getBatch(req: Request, res: Response, next: NextFunction) {
  try {
    const batch = await svc.getBatch(req.params.batchId);
    return ok(res, batch);
  } catch (err) {
    next(err);
  }
}

export async function getIssues(req: Request, res: Response, next: NextFunction) {
  try {
    const issues = await svc.getIssuesForBatch(req.params.batchId);
    return ok(res, issues);
  } catch (err) {
    next(err);
  }
}
