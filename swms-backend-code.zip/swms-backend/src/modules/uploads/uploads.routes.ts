import { Router } from "express";
import multer from "multer";
import { authenticate } from "../../middleware/auth";
import { env } from "../../config/env";
import * as ctrl from "./uploads.controller";

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: env.maxUploadSizeMb * 1024 * 1024 },
});

const router = Router();
router.use(authenticate);

router.post("/:habitationId/batches", upload.single("file"), ctrl.uploadBatch);
router.get("/batches/:batchId", ctrl.getBatch);
router.get("/batches/:batchId/issues", ctrl.getIssues);
// Note: the validation-dashboard endpoint is exposed at
// /api/habitations/:id/validation-dashboard (see dataQuality.routes.ts),
// not here, so it sits next to the other habitation-scoped GETs
// per the design document's Section 13.4 URL.

export default router;
