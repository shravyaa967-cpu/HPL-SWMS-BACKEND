import { Request, Response, NextFunction } from "express";
import { ok } from "../../utils/apiResponse";
import { AppError } from "../../utils/appError";
import { getHabitationOr404, assertCanWrite } from "../habitations/habitations.service";
import * as svc from "./parameters.service";
import { CATEGORY_REGISTRY, CategorySlug } from "./parameter.categories";

export async function getOne(req: Request, res: Response, next: NextFunction) {
  try {
    const category = req.params.category as CategorySlug;
    svc.assertValidCategory(category);
    await getHabitationOr404(req.params.habitationId); // 404 if habitation missing/deleted
    const record = await svc.getParameter(category, req.params.habitationId);
    return ok(res, record);
  } catch (err) {
    next(err);
  }
}

export async function upsert(req: Request, res: Response, next: NextFunction) {
  try {
    const category = req.params.category as CategorySlug;
    svc.assertValidCategory(category);
    const habitation = await getHabitationOr404(req.params.habitationId);
    assertCanWrite(habitation, req.user!);

    const { expectedVersion, ...data } = req.body;
    const record = await svc.upsertParameter(category, habitation.id, data, req.user!.sub, expectedVersion);
    return ok(res, record);
  } catch (err) {
    next(err);
  }
}

export async function history(req: Request, res: Response, next: NextFunction) {
  try {
    const category = req.query.category as string | undefined;
    if (category) svc.assertValidCategory(category);
    await getHabitationOr404(req.params.habitationId);
    const rows = await svc.getChangeHistory(req.params.habitationId, category);
    return ok(res, rows);
  } catch (err) {
    next(err);
  }
}

export function listCategories(_req: Request, res: Response) {
  return ok(res, Object.keys(CATEGORY_REGISTRY));
}
