import { PoolClient } from "pg";
import { pool, withTransaction } from "../../config/db";
import { AppError } from "../../utils/appError";
import { CATEGORY_REGISTRY, CategorySlug, toSnakeCase } from "./parameter.categories";

export function assertValidCategory(category: string): asserts category is CategorySlug {
  if (!(category in CATEGORY_REGISTRY)) {
    throw AppError.badRequest(
      `Unknown parameter category "${category}". Valid categories: ${Object.keys(CATEGORY_REGISTRY).join(", ")}`
    );
  }
}

export async function getParameter(category: CategorySlug, habitationId: string) {
  const { table } = CATEGORY_REGISTRY[category];
  const { rows } = await pool.query(
    `SELECT * FROM ${table} WHERE habitation_id = $1`,
    [habitationId]
  );
  if (rows.length === 0) {
    throw AppError.notFound(`No ${category} data recorded yet for this habitation`);
  }
  return rows[0];
}

/**
 * Section 5 Business Rules, applied identically to all 7 categories:
 *  - BR-01 first write for a habitation+category is a CREATE (INSERT)
 *  - BR-02 subsequent writes are UPDATE and require the current
 *    `version` (optimistic locking) — mismatch => 409 Conflict
 *  - BR-03 every changed field is appended to parameter_change_log
 *    (old_value/new_value as text) in the same transaction
 *  - BR-04 `updated_by` is always the authenticated user, never
 *    client-supplied
 *  - 13.2 `last_verified_at` is stamped `now()` whenever the caller
 *    supplies `source` or `captureMethod` (i.e. is actively asserting
 *    where the data came from), otherwise left untouched
 */
export async function upsertParameter(
  category: CategorySlug,
  habitationId: string,
  data: Record<string, unknown>,
  userId: string,
  expectedVersion?: number
) {
  const { table } = CATEGORY_REGISTRY[category];

  return withTransaction(async (client) => {
    const existingRes = await client.query(`SELECT * FROM ${table} WHERE habitation_id = $1 FOR UPDATE`, [
      habitationId,
    ]);
    const existing = existingRes.rows[0];

    const columns: Record<string, unknown> = {};
    for (const [key, value] of Object.entries(data)) {
      columns[toSnakeCase(key)] = value;
    }

    const touchesLineage = "source" in columns || "capture_method" in columns;
    if (touchesLineage) columns["last_verified_at"] = new Date();

    if (!existing) {
      columns["habitation_id"] = habitationId;
      columns["updated_by"] = userId;
      const keys = Object.keys(columns);
      const placeholders = keys.map((_, i) => `$${i + 1}`);
      const { rows } = await client.query(
        `INSERT INTO ${table} (${keys.join(", ")}) VALUES (${placeholders.join(", ")}) RETURNING *`,
        Object.values(columns)
      );
      return rows[0];
    }

    if (expectedVersion !== undefined && expectedVersion !== existing.version) {
      throw AppError.conflict(
        `This ${category} record has been updated by someone else since you last read it.`,
        { currentVersion: existing.version, expectedVersion }
      );
    }

    await logChanges(client, habitationId, category, existing, columns, userId);

    columns["updated_by"] = userId;
    const setClauses = Object.keys(columns).map((k, i) => `${k} = $${i + 2}`);
    const { rows } = await client.query(
      `UPDATE ${table} SET ${setClauses.join(", ")}, version = version + 1, updated_at = now()
       WHERE habitation_id = $1 RETURNING *`,
      [habitationId, ...Object.values(columns)]
    );
    return rows[0];
  });
}

async function logChanges(
  client: PoolClient,
  habitationId: string,
  category: string,
  existing: Record<string, unknown>,
  incoming: Record<string, unknown>,
  userId: string
) {
  for (const [field, newValue] of Object.entries(incoming)) {
    const oldValue = existing[field];
    if (String(oldValue) === String(newValue)) continue;
    await client.query(
      `INSERT INTO parameter_change_log (habitation_id, category, field_name, old_value, new_value, changed_by)
       VALUES ($1, $2, $3, $4, $5, $6)`,
      [habitationId, category, field, oldValue === null || oldValue === undefined ? null : String(oldValue), String(newValue), userId]
    );
  }
}

export async function getChangeHistory(habitationId: string, category?: string) {
  const params: unknown[] = [habitationId];
  let where = "habitation_id = $1";
  if (category) {
    params.push(category);
    where += " AND category = $2";
  }
  const { rows } = await pool.query(
    `SELECT * FROM parameter_change_log WHERE ${where} ORDER BY changed_at DESC LIMIT 200`,
    params
  );
  return rows;
}
