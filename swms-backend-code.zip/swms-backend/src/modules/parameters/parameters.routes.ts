import { Router, Request, Response, NextFunction } from "express";
import { z, ZodError } from "zod";
import { authenticate } from "../../middleware/auth";
import { AppError } from "../../utils/appError";
import { CATEGORY_REGISTRY } from "./parameter.categories";
import * as ctrl from "./parameters.controller";

const router = Router();
router.use(authenticate);

router.get("/categories", ctrl.listCategories);
router.get("/:habitationId/history", ctrl.history);
router.get("/:habitationId/:category", ctrl.getOne);

/**
 * PUT /parameters/:habitationId/:category
 * Validated dynamically because each category has its own Zod schema
 * (parameter.categories.ts) but they all share the same route shape --
 * see Section 5, "identical business rules across all 7 categories".
 */
router.put(
  "/:habitationId/:category",
  (req: Request, _res: Response, next: NextFunction) => {
    const def = CATEGORY_REGISTRY[req.params.category];
    if (!def) return next(AppError.badRequest(`Unknown parameter category "${req.params.category}"`));

    const bodySchema = def.schema.extend({ expectedVersion: z.number().int().optional() });
    try {
      req.body = bodySchema.parse(req.body);
      next();
    } catch (err) {
      if (err instanceof ZodError) {
        return next(
          AppError.badRequest(
            "Request validation failed",
            err.errors.map((e) => ({ path: e.path.join("."), message: e.message }))
          )
        );
      }
      next(err);
    }
  },
  ctrl.upsert
);

export default router;
