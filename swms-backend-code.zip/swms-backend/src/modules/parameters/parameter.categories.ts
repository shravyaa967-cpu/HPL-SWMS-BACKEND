import { z } from "zod";

/**
 * Section 4 note: all seven parameter-category tables share one
 * identical structural pattern (id, habitation_id, category fields,
 * lineage columns from 13.2, version, updated_at, updated_by). This
 * registry is the single source of truth mapping a URL category slug
 * to its table name and its Zod validation schema, so
 * parameters.service.ts can stay generic instead of duplicating CRUD
 * logic seven times (Section 5 "Business Rules apply identically
 * across all 7 categories").
 */

const lineageFields = {
  source: z.string().max(120).optional(),
  captureMethod: z.enum(["measured", "estimated", "imported", "default"]).optional(),
  confidenceScore: z.number().min(0).max(1).optional(),
};

export const demographySchema = z.object({
  population: z.number().int().min(0),
  populationDensityPerSqKm: z.number().int().min(0),
  growthRatePct: z.number().min(-100).max(100).default(0),
  floatingPopPct: z.number().min(0).max(100).default(0),
  householdSize: z.number().min(0).max(50).optional(),
  literacyPct: z.number().min(0).max(100).optional(),
  ...lineageFields,
});

export const infrastructureSchema = z.object({
  roadCoveragePct: z.number().min(0).max(100),
  roadsAlleysCount: z.number().int().min(0).default(0),
  residentialZonePct: z.number().min(0).max(100).default(0),
  industrialZonePct: z.number().min(0).max(100).default(0),
  schoolsCount: z.number().int().min(0).default(0),
  clinicsCount: z.number().int().min(0).default(0),
  collectionVehicles: z.number().int().min(0).default(0),
  collectionPointDensityPct: z.number().min(0).max(100).default(0),
  existingLandfillCapacityTonnes: z.number().min(0).default(0),
  ...lineageFields,
});

export const industrialSchema = z.object({
  hasOrganizedIndustry: z.boolean().default(false),
  hasUnorganizedIndustry: z.boolean().default(false),
  industrialActivityIntensity: z.enum(["low", "medium", "high"]).default("low"),
  industrialWasteTonnesPerDay: z.number().min(0).default(0),
  hazardousSharePct: z.number().min(0).max(100).default(0),
  ...lineageFields,
});

export const naturalResourceSchema = z.object({
  annualRainfallMm: z.number().min(0),
  waterBodiesCount: z.number().int().min(0).default(0),
  forestCoverPct: z.number().min(0).max(100).default(0),
  sensitiveAreaNearby: z.boolean().default(false),
  ...lineageFields,
});

export const terrainSchema = z.object({
  slope: z.string().min(1).max(40),
  soilType: z.string().min(1).max(60),
  windCondition: z.string().max(60).optional(),
  accessibility: z.enum(["low", "medium", "high"]).default("medium"),
  floodProne: z.boolean().default(false),
  ...lineageFields,
});

export const economicSchema = z.object({
  perCapitaIncomeAnnual: z.number().min(0),
  annualBudgetInr: z.number().min(0),
  willingnessToPayPct: z.number().min(0).max(100).default(0),
  costConstraintLevel: z.enum(["low", "moderate", "high", "severe"]).default("moderate"),
  ...lineageFields,
});

export const culturalSchema = z.object({
  dietType: z.string().max(60).optional(),
  segregationAdherencePct: z.number().min(0).max(100).default(0),
  festivalSpikePct: z.number().min(0).max(100).default(0),
  localPracticeNotes: z.string().max(2000).optional(),
  ...lineageFields,
});

interface CategoryDef {
  table: string;
  schema: z.ZodObject<any>;
}

export const CATEGORY_REGISTRY: Record<string, CategoryDef> = {
  demography: { table: "demography_parameters", schema: demographySchema },
  infrastructure: { table: "infrastructure_parameters", schema: infrastructureSchema },
  industrial: { table: "industrial_parameters", schema: industrialSchema },
  "natural-resources": { table: "natural_resource_parameters", schema: naturalResourceSchema },
  terrain: { table: "terrain_parameters", schema: terrainSchema },
  economic: { table: "economic_parameters", schema: economicSchema },
  cultural: { table: "cultural_parameters", schema: culturalSchema },
};

export type CategorySlug = keyof typeof CATEGORY_REGISTRY;

// camelCase (API/JS) <-> snake_case (SQL column) mapping, derived once.
export function toSnakeCase(s: string): string {
  return s.replace(/[A-Z]/g, (m) => `_${m.toLowerCase()}`);
}
