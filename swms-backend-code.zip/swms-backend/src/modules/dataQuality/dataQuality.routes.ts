import { Router, Request, Response, NextFunction } from "express";
import { authenticate } from "../../middleware/auth";
import { pool } from "../../config/db";
import { getHabitationOr404 } from "../habitations/habitations.service";
import { CATEGORY_REGISTRY } from "../parameters/parameter.categories";
import { ok } from "../../utils/apiResponse";
import { getValidationDashboard } from "../uploads/uploads.service";

const router = Router();
router.use(authenticate);

/**
 * Section 13.4 (Innovation) -- GET /api/habitations/:id/validation-dashboard
 * Read-only aggregation over validation_issues/upload_batches, mounted
 * here (rather than under /api/uploads) so every habitation-scoped GET
 * the design document lists in Section 13 lives under one consistent
 * /api/habitations/:id/... prefix.
 */
router.get("/:id/validation-dashboard", async (req: Request, res: Response, next: NextFunction) => {
  try {
    await getHabitationOr404(req.params.id);
    const dashboard = await getValidationDashboard(req.params.id);
    return ok(res, dashboard);
  } catch (err) {
    next(err);
  }
});


/**
 * Section 13.2 (Innovation) -- GET /api/habitations/:id/data-quality-summary
 * Aggregates confidence_score + last_verified_at across all 7 category
 * tables and map_layers into one 0-100 "data readiness" score, so a
 * Municipal Admin/Researcher can see at a glance whether a habitation's
 * data is trustworthy enough to feed the future 20-year simulation.
 */
router.get("/:id/data-quality-summary", async (req: Request, res: Response, next: NextFunction) => {
  try {
    await getHabitationOr404(req.params.id);

    const perCategory: Array<{ category: string; recorded: boolean; confidenceScore: number | null; lastVerifiedAt: string | null }> = [];

    for (const [slug, def] of Object.entries(CATEGORY_REGISTRY)) {
      const { rows } = await pool.query(
        `SELECT confidence_score, last_verified_at FROM ${def.table} WHERE habitation_id = $1`,
        [req.params.id]
      );
      if (rows.length === 0) {
        perCategory.push({ category: slug, recorded: false, confidenceScore: null, lastVerifiedAt: null });
      } else {
        perCategory.push({
          category: slug,
          recorded: true,
          confidenceScore: Number(rows[0].confidence_score),
          lastVerifiedAt: rows[0].last_verified_at,
        });
      }
    }

    const layersRes = await pool.query(
      `SELECT AVG(confidence_score)::float AS avg_confidence, COUNT(*)::int AS layer_count
       FROM map_layers WHERE habitation_id = $1 AND is_deleted = false AND status = 'ready'`,
      [req.params.id]
    );
    const layerSummary = layersRes.rows[0];

    const recordedCategories = perCategory.filter((c) => c.recorded);
    const categoryCompleteness = (recordedCategories.length / Object.keys(CATEGORY_REGISTRY).length) * 100;
    const avgConfidence =
      recordedCategories.length > 0
        ? (recordedCategories.reduce((sum, c) => sum + (c.confidenceScore ?? 0), 0) / recordedCategories.length) * 100
        : 0;
    const hasLayers = layerSummary.layer_count > 0;

    // Simple, transparent weighting: 50% "did you fill in all 7
    // categories", 40% "how confident is that data", 10% "is there any
    // GIS layer at all". Judges/planners can see the formula, not a
    // black box.
    const dataReadinessScore = Math.round(
      categoryCompleteness * 0.5 + avgConfidence * 0.4 + (hasLayers ? 100 : 0) * 0.1
    );

    return ok(res, {
      habitationId: req.params.id,
      dataReadinessScore,
      categoryCompleteness: Math.round(categoryCompleteness),
      averageConfidence: Math.round(avgConfidence),
      perCategory,
      gisLayers: { count: layerSummary.layer_count, averageConfidence: layerSummary.avg_confidence },
    });
  } catch (err) {
    next(err);
  }
});

export default router;
