import { Router } from "express";
import { validate } from "../../middleware/validate";
import { registerSchema, loginSchema, refreshSchema } from "./auth.schema";
import { registerHandler, loginHandler, refreshHandler } from "./auth.controller";

const router = Router();

router.post("/register", validate(registerSchema), registerHandler);
router.post("/login", validate(loginSchema), loginHandler);
router.post("/refresh", validate(refreshSchema), refreshHandler);

export default router;
