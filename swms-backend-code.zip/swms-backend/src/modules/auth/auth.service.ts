import { pool } from "../../config/db";
import { AppError } from "../../utils/appError";
import { hashPassword, verifyPassword } from "../../utils/password";
import { signAccessToken, signRefreshToken, verifyRefreshToken } from "../../utils/jwt";

export interface UserRecord {
  id: string;
  name: string;
  email: string;
  password_hash: string;
  role: "admin" | "planner" | "researcher";
  is_active: boolean;
}

async function findByEmail(email: string): Promise<UserRecord | null> {
  const { rows } = await pool.query<UserRecord>("SELECT * FROM users WHERE email = $1", [email]);
  return rows[0] ?? null;
}

export async function register(input: { name: string; email: string; password: string; role: "planner" | "researcher" }) {
  const existing = await findByEmail(input.email);
  if (existing) throw AppError.conflict("An account with this email already exists.");

  const passwordHash = await hashPassword(input.password);
  const { rows } = await pool.query<UserRecord>(
    `INSERT INTO users (name, email, password_hash, role) VALUES ($1, $2, $3, $4)
     RETURNING id, name, email, role, is_active`,
    [input.name, input.email, passwordHash, input.role]
  );
  return issueTokens(rows[0]);
}

export async function login(email: string, password: string) {
  const user = await findByEmail(email);
  if (!user || !user.is_active) throw AppError.unauthorized("Invalid email or password");

  const valid = await verifyPassword(password, user.password_hash);
  if (!valid) throw AppError.unauthorized("Invalid email or password");

  return issueTokens(user);
}

export async function refresh(refreshToken: string) {
  let payload: { sub: string };
  try {
    payload = verifyRefreshToken(refreshToken);
  } catch {
    throw AppError.unauthorized("Invalid or expired refresh token");
  }
  const { rows } = await pool.query<UserRecord>("SELECT * FROM users WHERE id = $1", [payload.sub]);
  const user = rows[0];
  if (!user || !user.is_active) throw AppError.unauthorized("Account no longer active");
  return issueTokens(user);
}

function issueTokens(user: Pick<UserRecord, "id" | "name" | "email" | "role">) {
  const accessToken = signAccessToken({ sub: user.id, role: user.role as any, email: user.email });
  const refreshToken = signRefreshToken(user.id);
  return {
    accessToken,
    refreshToken,
    user: { id: user.id, name: user.name, email: user.email, role: user.role },
  };
}
