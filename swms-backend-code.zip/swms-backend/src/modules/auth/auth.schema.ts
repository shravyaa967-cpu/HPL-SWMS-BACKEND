import { z } from "zod";

// Public self-registration is intentionally limited to planner/researcher.
// Admin accounts are provisioned only via the seed script or by an
// existing admin (see users.routes.ts POST /users, admin-only), so a
// self-service sign-up can never mint a privileged account.
export const registerSchema = z.object({
  body: z.object({
    name: z.string().min(2).max(120),
    email: z.string().email().max(160),
    password: z.string().min(8).max(72),
    role: z.enum(["planner", "researcher"]).default("researcher"),
  }),
  query: z.object({}).optional(),
  params: z.object({}).optional(),
});

export const loginSchema = z.object({
  body: z.object({
    email: z.string().email(),
    password: z.string().min(1),
  }),
  query: z.object({}).optional(),
  params: z.object({}).optional(),
});

export const refreshSchema = z.object({
  body: z.object({
    refreshToken: z.string().min(10),
  }),
  query: z.object({}).optional(),
  params: z.object({}).optional(),
});
