import { Router, Request, Response, NextFunction } from "express";
import { z } from "zod";
import { authenticate } from "../../middleware/auth";
import { validate } from "../../middleware/validate";
import { pool } from "../../config/db";
import { getHabitationOr404, assertCanWrite } from "../habitations/habitations.service";
import { CATEGORY_REGISTRY } from "../parameters/parameter.categories";
import { created, ok } from "../../utils/apiResponse";

const router = Router();
router.use(authenticate);

const createSnapshotSchema = z.object({
  body: z.object({ label: z.string().min(2).max(160) }),
  query: z.object({}).optional(),
  params: z.object({ id: z.string().uuid() }),
});

/**
 * Section 13.3 (Innovation) -- POST /api/habitations/:id/snapshots
 * Freezes an immutable, versioned copy of all 7 parameter categories
 * (+ their current `version` numbers) so a future simulation engine has
 * a reproducible input that does not silently change if the live
 * habitation data is edited afterward. No simulation logic reads this
 * table in Drop 1; it is pure data groundwork.
 */
router.post("/:id/snapshots", validate(createSnapshotSchema), async (req: Request, res: Response, next: NextFunction) => {
  try {
    const habitation = await getHabitationOr404(req.params.id);
    assertCanWrite(habitation, req.user!);

    const payload: Record<string, unknown> = {};
    const sourceVersions: Record<string, number> = {};

    for (const [slug, def] of Object.entries(CATEGORY_REGISTRY)) {
      const { rows } = await pool.query(`SELECT * FROM ${def.table} WHERE habitation_id = $1`, [habitation.id]);
      if (rows.length > 0) {
        payload[slug] = rows[0];
        sourceVersions[slug] = rows[0].version;
      }
    }

    const layers = await pool.query(
      "SELECT id, layer_type FROM map_layers WHERE habitation_id = $1 AND status = 'ready' AND is_deleted = false",
      [habitation.id]
    );
    payload["mapLayerRefs"] = layers.rows;

    const { rows } = await pool.query(
      `INSERT INTO parameter_snapshots (habitation_id, snapshot_label, payload, source_versions, taken_by)
       VALUES ($1, $2, $3, $4, $5) RETURNING id, snapshot_label, taken_at`,
      [habitation.id, req.body.label, JSON.stringify(payload), JSON.stringify(sourceVersions), req.user!.sub]
    );
    return created(res, rows[0]);
  } catch (err) {
    next(err);
  }
});

router.get("/:id/snapshots", async (req: Request, res: Response, next: NextFunction) => {
  try {
    await getHabitationOr404(req.params.id);
    const { rows } = await pool.query(
      "SELECT id, snapshot_label, source_versions, taken_at FROM parameter_snapshots WHERE habitation_id = $1 ORDER BY taken_at DESC",
      [req.params.id]
    );
    return ok(res, rows);
  } catch (err) {
    next(err);
  }
});

export default router;
