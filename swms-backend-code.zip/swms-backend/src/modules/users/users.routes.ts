import { Router, Request, Response, NextFunction } from "express";
import { z } from "zod";
import { pool } from "../../config/db";
import { authenticate } from "../../middleware/auth";
import { requireRole } from "../../middleware/rbac";
import { validate } from "../../middleware/validate";
import { hashPassword } from "../../utils/password";
import { ok, created } from "../../utils/apiResponse";
import { AppError } from "../../utils/appError";

const router = Router();
router.use(authenticate);

// Only an admin may list all users or create another admin/planner/researcher
// account directly (bypassing self-registration's planner/researcher-only limit).
const createUserSchema = z.object({
  body: z.object({
    name: z.string().min(2).max(120),
    email: z.string().email(),
    password: z.string().min(8).max(72),
    role: z.enum(["admin", "planner", "researcher"]),
  }),
  query: z.object({}).optional(),
  params: z.object({}).optional(),
});

router.get("/", requireRole("admin"), async (_req: Request, res: Response, next: NextFunction) => {
  try {
    const { rows } = await pool.query(
      "SELECT id, name, email, role, is_active, created_at FROM users ORDER BY created_at DESC"
    );
    return ok(res, rows);
  } catch (err) {
    next(err);
  }
});

router.post(
  "/",
  requireRole("admin"),
  validate(createUserSchema),
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const passwordHash = await hashPassword(req.body.password);
      const { rows } = await pool.query(
        `INSERT INTO users (name, email, password_hash, role) VALUES ($1, $2, $3, $4)
         RETURNING id, name, email, role, is_active, created_at`,
        [req.body.name, req.body.email, passwordHash, req.body.role]
      );
      return created(res, rows[0]);
    } catch (err) {
      next(err);
    }
  }
);

router.patch(
  "/:id/deactivate",
  requireRole("admin"),
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { rows } = await pool.query(
        "UPDATE users SET is_active = false, updated_at = now() WHERE id = $1 RETURNING id, is_active",
        [req.params.id]
      );
      if (rows.length === 0) throw AppError.notFound("User not found");
      return ok(res, rows[0]);
    } catch (err) {
      next(err);
    }
  }
);

router.get("/me", async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { rows } = await pool.query(
      "SELECT id, name, email, role, created_at FROM users WHERE id = $1",
      [req.user!.sub]
    );
    if (rows.length === 0) throw AppError.notFound("User not found");
    return ok(res, rows[0]);
  } catch (err) {
    next(err);
  }
});

export default router;
