import { Router } from "express";
import multer from "multer";
import { authenticate } from "../../middleware/auth";
import { validate } from "../../middleware/validate";
import { listLayersSchema } from "./mapLayers.schema";
import * as ctrl from "./mapLayers.controller";
import { env } from "../../config/env";

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: env.maxUploadSizeMb * 1024 * 1024 },
});

const router = Router();
router.use(authenticate);

router.post("/:habitationId/layers", upload.single("file"), ctrl.upload);
router.get("/:habitationId/layers", validate(listLayersSchema), ctrl.list);
router.get("/batches/:batchId/status", ctrl.status);

export default router;
