import { z } from "zod";

export const listLayersSchema = z.object({
  body: z.object({}).optional(),
  query: z.object({
    layerType: z.enum(["road", "water_body", "terrain", "settlement", "boundary"]).optional(),
    // bbox=minLon,minLat,maxLon,maxLat -- for map-viewport overlay queries (Section 3.C).
    bbox: z
      .string()
      .regex(/^-?\d+(\.\d+)?,-?\d+(\.\d+)?,-?\d+(\.\d+)?,-?\d+(\.\d+)?$/)
      .optional(),
  }),
  params: z.object({ habitationId: z.string().uuid() }),
});
