import { pool } from "../../config/db";
import { AppError } from "../../utils/appError";
import { geometryToEwkt, parseGeoFile } from "./geo.utils";
import { enqueue } from "../../queue/queue";

export async function createPendingLayerBatch(input: {
  habitationId: string;
  layerType: string;
  filename: string;
  storageKey: string;
  sourceUrl: string;
  uploadedBy: string;
}) {
  // One "batch" placeholder row so the client can poll status
  // immediately after upload; real feature rows are inserted by the
  // background job once parsing succeeds (Step 2, Validation & Mapping).
  const { rows } = await pool.query(
    `INSERT INTO map_layers (habitation_id, layer_type, geometry, source_file_url, status, uploaded_by)
     VALUES ($1, $2, ST_GeomFromText('POINT(0 0)', 4326), $3, 'processing', $4)
     RETURNING id`,
    [input.habitationId, input.layerType, input.sourceUrl, input.uploadedBy]
  );
  const placeholderId = rows[0].id;

  await enqueue("gis-normalization", {
    placeholderId,
    habitationId: input.habitationId,
    layerType: input.layerType,
    storageKey: input.storageKey,
    filename: input.filename,
    sourceUrl: input.sourceUrl,
    uploadedBy: input.uploadedBy,
  });

  return { batchId: placeholderId, status: "processing" };
}

/** Executed by the background worker (src/queue/jobs/gisNormalization.job.ts). */
export async function processGisUpload(job: {
  placeholderId: string;
  habitationId: string;
  layerType: string;
  fileBuffer: Buffer;
  filename: string;
  sourceUrl: string;
  uploadedBy: string;
}) {
  try {
    const features = await parseGeoFile(job.fileBuffer, job.filename);

    await pool.query("BEGIN");
    try {
      // Replace the placeholder with one row per parsed feature.
      await pool.query("DELETE FROM map_layers WHERE id = $1", [job.placeholderId]);
      for (const feature of features) {
        const ewkt = geometryToEwkt(feature.geometry);
        await pool.query(
          `INSERT INTO map_layers (habitation_id, layer_type, geometry, source_file_url, status, capture_method, uploaded_by)
           VALUES ($1, $2, ST_GeomFromEWKT($3), $4, 'ready', 'imported', $5)`,
          [job.habitationId, job.layerType, ewkt, job.sourceUrl, job.uploadedBy]
        );
      }
      await pool.query("COMMIT");
    } catch (err) {
      await pool.query("ROLLBACK");
      throw err;
    }
  } catch (err) {
    await pool.query(
      `UPDATE map_layers SET status = 'failed', failure_reason = $2 WHERE id = $1`,
      [job.placeholderId, (err as Error).message]
    );
  }
}

export async function listLayers(habitationId: string, opts: { layerType?: string; bbox?: string }) {
  const conditions = ["habitation_id = $1", "is_deleted = false", "status = 'ready'"];
  const params: unknown[] = [habitationId];

  if (opts.layerType) {
    params.push(opts.layerType);
    conditions.push(`layer_type = $${params.length}`);
  }
  if (opts.bbox) {
    const [minLon, minLat, maxLon, maxLat] = opts.bbox.split(",").map(Number);
    params.push(minLon, minLat, maxLon, maxLat);
    conditions.push(
      `geometry && ST_MakeEnvelope($${params.length - 3}, $${params.length - 2}, $${params.length - 1}, $${params.length}, 4326)`
    );
  }

  const { rows } = await pool.query(
    `SELECT id, habitation_id, layer_type, ST_AsGeoJSON(geometry) AS geometry, status,
            confidence_score, source, uploaded_at
     FROM map_layers WHERE ${conditions.join(" AND ")} ORDER BY uploaded_at DESC`,
    params
  );
  return rows.map((r) => ({ ...r, geometry: JSON.parse(r.geometry) }));
}

export async function getLayerBatchStatus(id: string) {
  const { rows } = await pool.query(
    "SELECT id, status, failure_reason FROM map_layers WHERE id = $1",
    [id]
  );
  if (rows.length === 0) throw AppError.notFound("Map layer batch not found");
  return rows[0];
}
