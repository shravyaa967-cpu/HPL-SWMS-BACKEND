import * as turf from "@turf/turf";
import shp from "shpjs";
import { AppError } from "../../utils/appError";

export interface ParsedFeature {
  geometry: GeoJSON.Geometry;
}

/**
 * Accepts either a GeoJSON file (.geojson/.json) or a zipped Shapefile
 * (.zip) and returns a flat list of validated geometries, matching
 * Section 3.C's requirement to ingest common GIS formats. Each geometry
 * is checked for basic structural validity (coordinate bounds, ring
 * closure via turf) before being handed to the caller -- genuinely
 * malformed geometry is rejected here (400) rather than being written
 * to PostGIS and failing silently later.
 */
export async function parseGeoFile(buffer: Buffer, filename: string): Promise<ParsedFeature[]> {
  const lower = filename.toLowerCase();
  let geojson: GeoJSON.FeatureCollection | GeoJSON.Feature;

  if (lower.endsWith(".zip")) {
    const result = await shp(buffer);
    geojson = Array.isArray(result) ? { type: "FeatureCollection", features: result.flatMap((r) => r.features) } : result;
  } else if (lower.endsWith(".geojson") || lower.endsWith(".json")) {
    try {
      geojson = JSON.parse(buffer.toString("utf-8"));
    } catch {
      throw AppError.badRequest("Uploaded file is not valid JSON/GeoJSON");
    }
  } else {
    throw AppError.badRequest("Unsupported GIS file type. Use .geojson, .json, or a zipped Shapefile (.zip)");
  }

  const features: GeoJSON.Feature[] =
    geojson.type === "FeatureCollection" ? geojson.features : [geojson as GeoJSON.Feature];

  if (features.length === 0) {
    throw AppError.unprocessable("File contains no features");
  }

  const parsed: ParsedFeature[] = [];
  for (const feature of features) {
    if (!feature.geometry) continue;
    validateGeometry(feature.geometry);
    parsed.push({ geometry: feature.geometry });
  }
  return parsed;
}

function validateGeometry(geometry: GeoJSON.Geometry) {
  // Coordinate bounds sanity check.
  const bbox = turf.bbox(geometry);
  const [minX, minY, maxX, maxY] = bbox;
  if (minX < -180 || maxX > 180 || minY < -90 || maxY > 90) {
    throw AppError.unprocessable("Geometry has coordinates outside valid longitude/latitude bounds");
  }

  // Self-intersection check for polygons (design doc Section 7 test case:
  // "invalid/self-intersecting geometry upload -> MapLayer status = failed").
  if (geometry.type === "Polygon" || geometry.type === "MultiPolygon") {
    try {
      const kinks = turf.kinks(geometry as GeoJSON.Feature<GeoJSON.Polygon | GeoJSON.MultiPolygon> | any);
      if (kinks.features.length > 0) {
        throw AppError.unprocessable("Polygon geometry is self-intersecting");
      }
    } catch (err) {
      if (err instanceof AppError) throw err;
      // turf.kinks can throw on certain degenerate polygons -- treat as invalid.
      throw AppError.unprocessable("Polygon geometry could not be validated (likely malformed)");
    }
  }
}

export function geometryToEwkt(geometry: GeoJSON.Geometry): string {
  return `SRID=4326;${geojsonToWkt(geometry)}`;
}

// Small dependency-free GeoJSON -> WKT converter (covers the geometry
// types relevant to GIS layers: Point, LineString, Polygon and their
// Multi* variants), avoiding an extra package for one conversion.
function geojsonToWkt(geometry: GeoJSON.Geometry): string {
  switch (geometry.type) {
    case "Point":
      return `POINT(${geometry.coordinates.join(" ")})`;
    case "LineString":
      return `LINESTRING(${ringToWkt(geometry.coordinates)})`;
    case "Polygon":
      return `POLYGON(${geometry.coordinates.map(ringToWktParens).join(",")})`;
    case "MultiPoint":
      return `MULTIPOINT(${geometry.coordinates.map((c) => c.join(" ")).join(",")})`;
    case "MultiLineString":
      return `MULTILINESTRING(${geometry.coordinates.map(ringToWktParens).join(",")})`;
    case "MultiPolygon":
      return `MULTIPOLYGON(${geometry.coordinates
        .map((poly) => `(${poly.map(ringToWktParens).join(",")})`)
        .join(",")})`;
    default:
      throw AppError.unprocessable(`Unsupported geometry type: ${(geometry as any).type}`);
  }
}
function ringToWkt(coords: number[][]): string {
  return coords.map((c) => c.join(" ")).join(",");
}
function ringToWktParens(coords: number[][]): string {
  return `(${ringToWkt(coords)})`;
}
