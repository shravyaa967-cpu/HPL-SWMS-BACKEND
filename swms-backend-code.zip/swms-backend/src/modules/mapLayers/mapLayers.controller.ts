import { Request, Response, NextFunction } from "express";
import { ok, created } from "../../utils/apiResponse";
import { AppError } from "../../utils/appError";
import { getHabitationOr404, assertCanWrite } from "../habitations/habitations.service";
import { saveBuffer } from "../../utils/storage";
import * as svc from "./mapLayers.service";

const VALID_LAYER_TYPES = ["road", "water_body", "terrain", "settlement", "boundary"];

export async function upload(req: Request, res: Response, next: NextFunction) {
  try {
    const habitation = await getHabitationOr404(req.params.habitationId);
    assertCanWrite(habitation, req.user!);

    if (!req.file) throw AppError.badRequest("No file uploaded (field name: file)");
    const layerType = req.body.layerType;
    if (!VALID_LAYER_TYPES.includes(layerType)) {
      throw AppError.badRequest(`layerType must be one of: ${VALID_LAYER_TYPES.join(", ")}`);
    }

    const { storageKey, url } = saveBuffer(req.file.buffer, req.file.originalname);
    const result = await svc.createPendingLayerBatch({
      habitationId: habitation.id,
      layerType,
      filename: req.file.originalname,
      storageKey,
      sourceUrl: url,
      uploadedBy: req.user!.sub,
    });
    return created(res, result);
  } catch (err) {
    next(err);
  }
}

export async function list(req: Request, res: Response, next: NextFunction) {
  try {
    await getHabitationOr404(req.params.habitationId);
    const { layerType, bbox } = req.query as { layerType?: string; bbox?: string };
    const layers = await svc.listLayers(req.params.habitationId, { layerType, bbox });
    return ok(res, layers);
  } catch (err) {
    next(err);
  }
}

export async function status(req: Request, res: Response, next: NextFunction) {
  try {
    const result = await svc.getLayerBatchStatus(req.params.batchId);
    return ok(res, result);
  } catch (err) {
    next(err);
  }
}
