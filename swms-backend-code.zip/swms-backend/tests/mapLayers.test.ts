import { describe, it, expect, beforeAll } from "vitest";
import request from "supertest";
import { app } from "../src/app";

async function registerAndLogin() {
  const email = `planner-${Date.now()}-${Math.random().toString(36).slice(2)}@swms.local`;
  await request(app).post("/api/auth/register").send({ name: "Planner Tester", email, password: "SecurePass123!", role: "planner" });
  const login = await request(app).post("/api/auth/login").send({ email, password: "SecurePass123!" });
  return login.body.data.accessToken as string;
}

// A bowtie polygon: self-intersecting, invalid per OGC simple-feature rules.
const selfIntersectingGeoJson = {
  type: "Feature",
  properties: {},
  geometry: {
    type: "Polygon",
    coordinates: [
      [
        [74.7, 13.3],
        [74.8, 13.4],
        [74.7, 13.4],
        [74.8, 13.3],
        [74.7, 13.3],
      ],
    ],
  },
};

describe("GIS map layer upload", () => {
  let token: string;
  let habitationId: string;

  beforeAll(async () => {
    token = await registerAndLogin();
    const res = await request(app)
      .post("/api/habitations")
      .set("Authorization", `Bearer ${token}`)
      .send({ name: "GIS Test Habitation", type: "town", latitude: 13.3, longitude: 74.7 });
    habitationId = res.body.data.id;
  });

  it("accepts the upload synchronously (202-style 201) then marks the batch failed for self-intersecting geometry", async () => {
    const buffer = Buffer.from(JSON.stringify(selfIntersectingGeoJson));

    const uploadRes = await request(app)
      .post(`/api/habitations/${habitationId}/layers`)
      .set("Authorization", `Bearer ${token}`)
      .field("layerType", "boundary")
      .attach("file", buffer, "bad-boundary.geojson");

    expect(uploadRes.status).toBe(201);
    const batchId = uploadRes.body.data.batchId;

    // Fallback in-process queue processes synchronously-ish via
    // setImmediate; poll briefly for the async job to finish.
    let status = "processing";
    for (let i = 0; i < 20 && status === "processing"; i++) {
      await new Promise((r) => setTimeout(r, 100));
      const statusRes = await request(app)
        .get(`/api/habitations/batches/${batchId}/status`)
        .set("Authorization", `Bearer ${token}`);
      status = statusRes.body.data.status;
    }
    expect(status).toBe("failed");
  });

  it("rejects an upload with no layerType with 400", async () => {
    const buffer = Buffer.from(JSON.stringify(selfIntersectingGeoJson));
    const res = await request(app)
      .post(`/api/habitations/${habitationId}/layers`)
      .set("Authorization", `Bearer ${token}`)
      .attach("file", buffer, "no-type.geojson");
    expect(res.status).toBe(400);
  });
});
