/**
 * Integration tests. Require a running Postgres+PostGIS instance with
 * migrations applied (see README "Testing" section):
 *   docker compose up -d
 *   npm run migrate
 *   npm test
 */
import { describe, it, expect, beforeAll } from "vitest";
import request from "supertest";
import { app } from "../src/app";

describe("Auth", () => {
  const email = `test-${Date.now()}@swms.local`;

  it("registers a new planner account", async () => {
    const res = await request(app)
      .post("/api/auth/register")
      .send({ name: "Test Planner", email, password: "SecurePass123!", role: "planner" });

    expect(res.status).toBe(201);
    expect(res.body.success).toBe(true);
    expect(res.body.data.accessToken).toBeDefined();
    expect(res.body.data.user.role).toBe("planner");
  });

  it("rejects self-registration as admin (role coerced/rejected)", async () => {
    const res = await request(app)
      .post("/api/auth/register")
      .send({ name: "Sneaky", email: `sneaky-${Date.now()}@swms.local`, password: "SecurePass123!", role: "admin" });

    // 'admin' is not in the public registration enum -> Zod validation failure.
    expect(res.status).toBe(400);
  });

  it("rejects login with wrong password", async () => {
    const res = await request(app).post("/api/auth/login").send({ email, password: "WrongPassword" });
    expect(res.status).toBe(401);
    expect(res.body.error.code).toBe("UNAUTHORIZED");
  });

  it("logs in with correct credentials", async () => {
    const res = await request(app).post("/api/auth/login").send({ email, password: "SecurePass123!" });
    expect(res.status).toBe(200);
    expect(res.body.data.accessToken).toBeDefined();
  });

  it("rejects an unauthenticated request to a protected route", async () => {
    const res = await request(app).get("/api/habitations");
    expect(res.status).toBe(401);
  });
});
