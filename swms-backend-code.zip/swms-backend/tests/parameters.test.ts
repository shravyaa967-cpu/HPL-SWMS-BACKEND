import { describe, it, expect, beforeAll } from "vitest";
import request from "supertest";
import { app } from "../src/app";

async function registerAndLogin(role: "planner" | "researcher") {
  const email = `${role}-${Date.now()}-${Math.random().toString(36).slice(2)}@swms.local`;
  await request(app).post("/api/auth/register").send({ name: role, email, password: "SecurePass123!", role });
  const login = await request(app).post("/api/auth/login").send({ email, password: "SecurePass123!" });
  return login.body.data.accessToken as string;
}

describe("Habitations + Parameters", () => {
  let plannerToken: string;
  let researcherToken: string;
  let habitationId: string;

  beforeAll(async () => {
    plannerToken = await registerAndLogin("planner");
    researcherToken = await registerAndLogin("researcher");

    const res = await request(app)
      .post("/api/habitations")
      .set("Authorization", `Bearer ${plannerToken}`)
      .send({ name: "Test Ward", type: "ward", latitude: 12.9, longitude: 74.8 });
    habitationId = res.body.data.id;
  });

  it("creates the demography record on first write (BR-01)", async () => {
    const res = await request(app)
      .put(`/api/parameters/${habitationId}/demography`)
      .set("Authorization", `Bearer ${plannerToken}`)
      .send({ population: 5000, populationDensityPerSqKm: 400 });

    expect(res.status).toBe(200);
    expect(res.body.data.version).toBe(1);
  });

  it("rejects an update with a stale expectedVersion (optimistic locking, 409)", async () => {
    const res = await request(app)
      .put(`/api/parameters/${habitationId}/demography`)
      .set("Authorization", `Bearer ${plannerToken}`)
      .send({ population: 5200, populationDensityPerSqKm: 410, expectedVersion: 99 });

    expect(res.status).toBe(409);
    expect(res.body.error.code).toBe("CONFLICT");
  });

  it("a researcher can read but not write parameters (RBAC)", async () => {
    const readRes = await request(app)
      .get(`/api/parameters/${habitationId}/demography`)
      .set("Authorization", `Bearer ${researcherToken}`);
    expect(readRes.status).toBe(200);

    const writeRes = await request(app)
      .put(`/api/parameters/${habitationId}/demography`)
      .set("Authorization", `Bearer ${researcherToken}`)
      .send({ population: 1, populationDensityPerSqKm: 1 });
    expect(writeRes.status).toBe(403);
  });

  it("rejects an unknown parameter category with 400", async () => {
    const res = await request(app)
      .put(`/api/parameters/${habitationId}/not-a-real-category`)
      .set("Authorization", `Bearer ${plannerToken}`)
      .send({ foo: "bar" });
    expect(res.status).toBe(400);
  });

  it("records a parameter_change_log entry on update", async () => {
    await request(app)
      .put(`/api/parameters/${habitationId}/demography`)
      .set("Authorization", `Bearer ${plannerToken}`)
      .send({ population: 5300, populationDensityPerSqKm: 420, expectedVersion: 1 });

    const historyRes = await request(app)
      .get(`/api/parameters/${habitationId}/history?category=demography`)
      .set("Authorization", `Bearer ${plannerToken}`);

    expect(historyRes.status).toBe(200);
    expect(historyRes.body.data.length).toBeGreaterThan(0);
  });
});
